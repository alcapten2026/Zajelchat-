export type MessageType = 'text' | 'image' | 'audio' | 'video' | 'file';

export interface CryptoMetadata {
  algorithm: 'AES-256-GCM';
  iv: string; // base64
  salt?: string; // base64 for password derived keys
  tagLength: number; // 128 bit
  isPasswordProtected: boolean;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  content: string; // Plaintext when decrypted
  encryptedPayload?: string; // Raw ciphertext base64
  cryptoMeta: CryptoMetadata;
  type: MessageType;
  fileData?: {
    name: string;
    size: number;
    mimeType: string;
    dataUrl: string; // base64 or blob url
    duration?: number; // for audio
  };
  timestamp: number;
  status: 'sending' | 'sent' | 'delivered' | 'failed';
  isDecrypted: boolean;
  decryptionError?: boolean;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group';
  name: string;
  avatar: string;
  peerDeviceId?: string; // MAC or UUID
  isPasswordProtected: boolean;
  channelPassword?: string; // stored locally if unlocked
  isUnlocked?: boolean;
  lastMessage?: string;
  lastMessageTime?: number;
  unreadCount: number;
  membersCount?: number;
  description?: string;
}

export interface BluetoothDevice {
  id: string; // MAC address or Bluetooth UUID
  name: string;
  rssi: number; // e.g., -45 dBm
  distanceMeters: number;
  status: 'discovered' | 'connecting' | 'connected' | 'blocked';
  lastSeen: number;
  supportedServices: string[];
  publicKey?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  bio: string;
  avatar: string;
  bluetoothAddress: string; // Simulated or real MAC: e.g. 74:D2:1D:9C:AA:01
  bluetoothName: string;
  createdAt: number;
}

export interface BlockedDevice {
  id: string; // MAC or UUID
  name: string;
  blockedAt: number;
  reason?: string;
}
