import React, { useState, useRef, useEffect } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Lock,
  Unlock,
  KeyRound,
  Download,
  Play,
  Pause,
  FileText,
  Trash2,
  Info,
  Clock,
  Check,
  CheckCheck,
  Smartphone,
  Users,
  Eye,
  Volume2
} from 'lucide-react';
import { Conversation, Message, UserProfile, CryptoMetadata } from '../types';

interface ChatAreaProps {
  conversation: Conversation | null;
  messages: Message[];
  currentProfile: UserProfile;
  onBlockPeer?: (peerDeviceId: string, peerName: string) => void;
  onClearHistory: () => void;
  onInspectCrypto: (msg: Message) => void;
  onPromptUnlock: () => void;
  isLocked: boolean;
}

export const ChatArea: React.FC<ChatAreaProps> = ({
  conversation,
  messages,
  currentProfile,
  onBlockPeer,
  onClearHistory,
  onInspectCrypto,
  onPromptUnlock,
  isLocked,
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const audioElementsRef = useRef<Map<string, HTMLAudioElement>>(new Map());

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleToggleAudio = (msgId: string, dataUrl: string) => {
    let audio = audioElementsRef.current.get(msgId);
    if (!audio) {
      audio = new Audio(dataUrl);
      audioElementsRef.current.set(msgId, audio);
      audio.onended = () => setPlayingAudioId(null);
    }

    if (playingAudioId === msgId) {
      audio.pause();
      setPlayingAudioId(null);
    } else {
      // Pause any other playing audio
      audioElementsRef.current.forEach((a, id) => {
        if (id !== msgId) a.pause();
      });
      audio.play();
      setPlayingAudioId(msgId);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} بايت`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} ك.ب`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} م.ب`;
  };

  const formatTime = (ts: number) => {
    return new Date(ts).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  };

  if (!conversation) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-sky-50/40 dark:bg-slate-900/40">
        <div className="w-24 h-24 mb-4 rounded-3xl bg-white dark:bg-slate-800 p-2 shadow-xl border border-sky-100 dark:border-slate-700 flex items-center justify-center animate-bounce [animation-duration:3s]">
          <img
            src="/assets/aistudio/a_clean_high_resolution_isolated_illustration_gra_ed286f78.png"
            alt="زاجل شات"
            className="w-full h-full object-contain filter drop-shadow"
          />
        </div>
        <h2 className="text-xl font-black text-slate-800 dark:text-white mb-2">
          مرحباً بك في «زاجل شات»
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-md leading-relaxed">
          اختر محادثة خاصة أو غرفة جماعية من القائمة، أو افتح رادار البلوتوث لاكتشاف الهواتف المجاورة والتواصل المباشر المشفر دون إنترنت.
        </p>
        <div className="mt-4 px-3 py-1.5 rounded-full bg-sky-100 dark:bg-slate-800 text-sky-800 dark:text-sky-300 text-xs font-bold border border-sky-200 dark:border-slate-700">
          تطوير: سلامة تكنولوجي • م/ بسام عبدالرقيب الشميري
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-50 dark:bg-slate-950/60 overflow-hidden relative">
      {/* Chat Top Header */}
      <div className="px-4 py-3 bg-white dark:bg-slate-900 border-b border-sky-100 dark:border-slate-800 flex items-center justify-between shadow-xs z-10">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-2xl bg-sky-100 dark:bg-slate-800 border border-sky-200 dark:border-slate-700 flex items-center justify-center text-lg shrink-0">
            {conversation.avatar || (conversation.type === 'group' ? '👥' : '📱')}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black text-slate-900 dark:text-white truncate">
                {conversation.name}
              </h2>
              {conversation.isPasswordProtected && (
                <button
                  onClick={onPromptUnlock}
                  className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-300 dark:border-amber-800"
                  title="حالة القفل والتشفير"
                >
                  {isLocked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3 text-emerald-500" />}
                  <span>{isLocked ? 'مقفل بكلمة مرور' : 'تم فك التشفير'}</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400">
                <ShieldCheck className="w-3 h-3" />
                تشفير AES-256-GCM نشط
              </span>
              <span>•</span>
              {conversation.type === 'direct' ? (
                <span className="font-mono text-[10px]">
                  MAC: {conversation.peerDeviceId || 'RFCOMM P2P'}
                </span>
              ) : (
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {conversation.membersCount || 1} أجهزة متصلة
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Header Actions */}
        <div className="flex items-center gap-1.5">
          {conversation.type === 'direct' && conversation.peerDeviceId && onBlockPeer && (
            <button
              onClick={() => onBlockPeer(conversation.peerDeviceId!, conversation.name)}
              className="px-2.5 py-1.5 rounded-xl text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
              title="حظر هذا الجهاز البلوتوث"
            >
              <ShieldAlert className="w-4 h-4 text-red-500" />
              <span className="hidden sm:inline">حظر الجهاز</span>
            </button>
          )}

          <button
            onClick={onClearHistory}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title="مسح سجل المحادثة المحلي"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-gradient-to-b from-sky-50/20 to-transparent">
        {/* Security Banner */}
        <div className="p-3 mx-auto max-w-lg rounded-2xl bg-sky-100/70 dark:bg-slate-800/80 border border-sky-200 dark:border-slate-700 text-center text-xs text-slate-600 dark:text-slate-300 shadow-xs">
          <div className="flex items-center justify-center gap-1.5 font-bold text-sky-800 dark:text-sky-300 mb-1">
            <Lock className="w-3.5 h-3.5" />
            <span>رسائل هذه المحادثة مشفرة محلياً بـ AES-GCM 256-bit</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            تنتقل البيانات عبر موجات البلوتوث مباشرة دون إنترنت ولا يستطيع أي طرف ثالث قراءتها.
          </p>
        </div>

        {messages.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400">
            لا توجد رسائل بعد. ابدأ المحادثة وأرسل رسالة نصية أو صورة أو تسجيل صوتي!
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = msg.senderId === currentProfile.id;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-start' : 'items-end'}`}
              >
                {/* Sender Header for group chats */}
                {!isMe && conversation.type === 'group' && (
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-0.5 px-2">
                    {msg.senderName}
                  </span>
                )}

                {/* Message Bubble Container */}
                <div
                  className={`max-w-[85%] sm:max-w-[70%] rounded-2xl px-3.5 py-2.5 shadow-sm transition relative group ${
                    isMe
                      ? 'bg-sky-500 text-white rounded-br-xs'
                      : 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-sky-100 dark:border-slate-700 rounded-bl-xs'
                  }`}
                >
                  {/* TEXT CONTENT */}
                  {msg.type === 'text' && (
                    <p className="text-xs sm:text-sm whitespace-pre-wrap break-words leading-relaxed select-text">
                      {msg.content}
                    </p>
                  )}

                  {/* IMAGE CONTENT */}
                  {msg.type === 'image' && msg.fileData && (
                    <div className="space-y-1.5">
                      <div
                        onClick={() => setLightboxImage(msg.fileData!.dataUrl)}
                        className="rounded-xl overflow-hidden cursor-pointer max-h-72 bg-slate-100 dark:bg-slate-900"
                      >
                        <img
                          src={msg.fileData.dataUrl}
                          alt={msg.fileData.name}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-200"
                        />
                      </div>
                      <div className="text-[10px] opacity-80 flex items-center justify-between">
                        <span className="truncate max-w-[150px]">{msg.fileData.name}</span>
                        <span>{formatFileSize(msg.fileData.size)}</span>
                      </div>
                    </div>
                  )}

                  {/* AUDIO VOICE NOTE */}
                  {msg.type === 'audio' && msg.fileData && (
                    <div className="flex items-center gap-3 py-1 min-w-[200px]">
                      <button
                        onClick={() => handleToggleAudio(msg.id, msg.fileData!.dataUrl)}
                        className={`w-9 h-9 rounded-full flex items-center justify-center text-white transition active:scale-90 cursor-pointer shadow-sm ${
                          isMe ? 'bg-white text-sky-600' : 'bg-sky-500 text-white'
                        }`}
                      >
                        {playingAudioId === msg.id ? (
                          <Pause className="w-4 h-4 fill-current" />
                        ) : (
                          <Play className="w-4 h-4 fill-current ml-0.5" />
                        )}
                      </button>

                      <div className="flex-1">
                        {/* Fake Waveform */}
                        <div className="flex items-center gap-0.5 h-6">
                          {[40, 70, 30, 90, 50, 80, 60, 100, 45, 85, 55, 75, 35, 95].map((h, i) => (
                            <div
                              key={i}
                              style={{ height: `${h}%` }}
                              className={`w-1 rounded-full ${
                                isMe
                                  ? 'bg-sky-200/90'
                                  : 'bg-sky-500/80'
                              } ${playingAudioId === msg.id ? 'animate-pulse' : ''}`}
                            ></div>
                          ))}
                        </div>
                        <div className="flex items-center justify-between text-[10px] opacity-80 mt-0.5">
                          <span>تسجيل صوتي</span>
                          <span>{msg.fileData.duration ? `${msg.fileData.duration} ثانية` : '0:05'}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* VIDEO CONTENT */}
                  {msg.type === 'video' && msg.fileData && (
                    <div className="space-y-1.5 max-w-sm">
                      <video
                        src={msg.fileData.dataUrl}
                        controls
                        className="rounded-xl w-full max-h-64 bg-black"
                      />
                      <div className="text-[10px] opacity-80 flex items-center justify-between">
                        <span className="truncate max-w-[150px]">{msg.fileData.name}</span>
                        <span>{formatFileSize(msg.fileData.size)}</span>
                      </div>
                    </div>
                  )}

                  {/* DOCUMENT FILE CONTENT */}
                  {msg.type === 'file' && msg.fileData && (
                    <div className="flex items-center gap-3 p-2 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 min-w-[220px]">
                      <div className="w-9 h-9 rounded-lg bg-sky-500 text-white flex items-center justify-center shrink-0">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold truncate">{msg.fileData.name}</p>
                        <p className="text-[10px] opacity-80">{formatFileSize(msg.fileData.size)}</p>
                      </div>
                      <a
                        href={msg.fileData.dataUrl}
                        download={msg.fileData.name}
                        className={`p-1.5 rounded-lg transition ${
                          isMe
                            ? 'hover:bg-white/20 text-white'
                            : 'hover:bg-slate-200 dark:hover:bg-slate-700 text-sky-600 dark:text-sky-400'
                        }`}
                        title="تحميل الملف"
                      >
                        <Download className="w-4 h-4" />
                      </a>
                    </div>
                  )}

                  {/* Footer Meta & Crypto Inspection Trigger */}
                  <div
                    className={`flex items-center justify-between gap-3 mt-1.5 pt-1 border-t text-[10px] ${
                      isMe ? 'border-white/20 text-sky-100' : 'border-slate-100 dark:border-slate-700 text-slate-400'
                    }`}
                  >
                    {/* AES Badge Inspector button */}
                    <button
                      onClick={() => onInspectCrypto(msg)}
                      className={`flex items-center gap-1 font-mono hover:underline cursor-pointer ${
                        isMe ? 'text-sky-100' : 'text-sky-600 dark:text-sky-400 font-bold'
                      }`}
                      title="فحص بيانات التشفير AES-256-GCM و IV"
                    >
                      <Lock className="w-2.5 h-2.5" />
                      <span>AES-GCM</span>
                    </button>

                    <div className="flex items-center gap-1">
                      <span>{formatTime(msg.timestamp)}</span>
                      {isMe && (
                        <span>
                          {msg.status === 'delivered' ? (
                            <CheckCheck className="w-3.5 h-3.5 text-sky-200" />
                          ) : (
                            <Check className="w-3.5 h-3.5 text-sky-200" />
                          )}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Lightbox Modal for Images */}
      {lightboxImage && (
        <div
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 cursor-pointer"
        >
          <img
            src={lightboxImage}
            alt="صورة مكبرة"
            className="max-w-full max-h-full object-contain rounded-xl"
          />
        </div>
      )}
    </div>
  );
};
