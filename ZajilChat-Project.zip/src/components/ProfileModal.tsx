import React, { useState } from 'react';
import { X, Save, User, Smartphone, Bluetooth, ShieldCheck, Heart } from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  onSave: (updated: UserProfile) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  onSave,
}) => {
  const [name, setName] = useState(profile.name);
  const [bio, setBio] = useState(profile.bio);
  const [avatar, setAvatar] = useState(profile.avatar);
  const [bluetoothName, setBluetoothName] = useState(profile.bluetoothName);

  if (!isOpen) return null;

  const AVATAR_OPTIONS = ['🕊️', '🦅', '🦁', '⚡', '🔒', '🛡️', '🛰️', '👑', '📱', '🌟'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...profile,
      name: name.trim() || 'مستخدم زاجل',
      bio: bio.trim(),
      avatar,
      bluetoothName: bluetoothName.trim() || 'Zajil_Device',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-sky-100 dark:border-slate-800 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 bg-sky-50 dark:bg-slate-800/60 border-b border-sky-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-sky-500 text-white flex items-center justify-center shadow-md">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900 dark:text-white">
                الملف الشخصي وهوية البلوتوث
              </h2>
              <p className="text-[11px] text-slate-500">معلوماتك مخزنة محلياً على جهازك دون إنترنت</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Avatar Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              الصورة الرمزية (الأيقونة)
            </label>
            <div className="flex flex-wrap gap-2">
              {AVATAR_OPTIONS.map((icon) => (
                <button
                  key={icon}
                  type="button"
                  onClick={() => setAvatar(icon)}
                  className={`w-10 h-10 rounded-xl text-lg flex items-center justify-center transition border ${
                    avatar === icon
                      ? 'bg-sky-500 text-white border-sky-600 scale-105 shadow-md'
                      : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:bg-sky-50'
                  }`}
                >
                  {icon}
                </button>
              ))}
            </div>
          </div>

          {/* User Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              الاسم المستعار في المحادثات
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Bio */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              الحالة / النبذة الشخصية
            </label>
            <input
              type="text"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Bluetooth Hardware Details */}
          <div className="p-3.5 rounded-2xl bg-sky-50 dark:bg-slate-800/70 border border-sky-100 dark:border-slate-700 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-sky-800 dark:text-sky-300">
              <Bluetooth className="w-4 h-4 text-sky-500" />
              <span>بيانات عتاد البلوتوث (RFCOMM)</span>
            </div>

            <div>
              <label className="block text-[11px] text-slate-500 dark:text-slate-400 mb-0.5">
                اسم الجهاز المرئي للبلوتوث
              </label>
              <input
                type="text"
                value={bluetoothName}
                onChange={(e) => setBluetoothName(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-600 dark:text-slate-400 pt-1">
              <span>عنوان MAC:</span>
              <span className="font-bold text-sky-600 dark:text-sky-400">{profile.bluetoothAddress}</span>
            </div>
          </div>

          {/* Developer Attribution Card */}
          <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-50 to-sky-50 dark:from-slate-800 dark:to-slate-800/60 border border-amber-200 dark:border-slate-700 flex items-center gap-3">
            <img
              src="/assets/aistudio/a_clean_high_resolution_isolated_illustration_gra_ed286f78.png"
              alt="شعار المطور"
              className="w-9 h-9 object-contain"
            />
            <div className="text-[11px]">
              <div className="font-black text-slate-900 dark:text-white">
                تطوير: سلامة تكنولوجي
              </div>
              <div className="text-slate-600 dark:text-slate-300 font-medium">
                م/ بسام عبدالرقيب الشميري
              </div>
            </div>
          </div>

          {/* Submit */}
          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold shadow-md transition active:scale-95 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>حفظ التعديلات</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
