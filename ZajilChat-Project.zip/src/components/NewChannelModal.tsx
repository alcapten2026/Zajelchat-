import React, { useState } from 'react';
import { X, Plus, Lock, Users, Smartphone, ShieldCheck, KeyRound } from 'lucide-react';
import { BluetoothDevice, Conversation } from '../types';

interface NewChannelModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType: 'direct' | 'group';
  discoveredDevices: BluetoothDevice[];
  onCreate: (conversation: Partial<Conversation>) => void;
}

export const NewChannelModal: React.FC<NewChannelModalProps> = ({
  isOpen,
  onClose,
  initialType,
  discoveredDevices,
  onCreate,
}) => {
  const [type, setType] = useState<'direct' | 'group'>(initialType);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [avatar, setAvatar] = useState('👥');
  const [selectedDeviceId, setSelectedDeviceId] = useState(
    discoveredDevices[0]?.id || ''
  );
  const [isPasswordProtected, setIsPasswordProtected] = useState(false);
  const [password, setPassword] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (type === 'direct') {
      const dev = discoveredDevices.find((d) => d.id === selectedDeviceId);
      onCreate({
        id: `conv_${Date.now()}`,
        type: 'direct',
        name: dev ? dev.name : (name.trim() || 'هاتف بلوتوث'),
        avatar: '📱',
        peerDeviceId: selectedDeviceId || '74:D2:1D:9C:AA:01',
        isPasswordProtected: false,
        unreadCount: 0,
        description: 'محادثة بلوتوث مباشرة P2P',
      });
    } else {
      if (!name.trim()) return;
      onCreate({
        id: `room_${Date.now()}`,
        type: 'group',
        name: name.trim(),
        avatar: isPasswordProtected ? '🔐' : avatar,
        isPasswordProtected,
        channelPassword: isPasswordProtected ? password.trim() : undefined,
        isUnlocked: true,
        unreadCount: 0,
        membersCount: 1,
        description: description.trim() || (isPasswordProtected ? 'غرفة جماعية مشفرة بكلمة مرور' : 'غرفة شبكة بلوتوث عامة'),
      });
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-sky-100 dark:border-slate-800 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 bg-sky-50 dark:bg-slate-800/60 border-b border-sky-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-sky-500 text-white flex items-center justify-center shadow-md">
              <Plus className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900 dark:text-white">
                {type === 'direct' ? 'بدء محادثة خاصة P2P' : 'إنشاء غرفة شبكة مشفرة'}
              </h2>
              <p className="text-[11px] text-slate-500">اتصال فوري عبر البلوتوث دون إنترنت</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="p-3 bg-sky-100/50 dark:bg-slate-800/50 flex gap-1 mx-4 mt-4 rounded-xl">
          <button
            type="button"
            onClick={() => setType('direct')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition ${
              type === 'direct'
                ? 'bg-white dark:bg-sky-600 text-sky-700 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            محادثة خاصة P2P
          </button>
          <button
            type="button"
            onClick={() => setType('group')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition ${
              type === 'group'
                ? 'bg-white dark:bg-sky-600 text-sky-700 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            غرفة جماعية / مشفرة
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {type === 'direct' ? (
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                اختر جهاز بلوتوث من الأجهزة المكتشفة
              </label>
              {discoveredDevices.length === 0 ? (
                <div className="p-3 text-xs text-amber-800 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200">
                  لم يتم كشف أجهزة بعد. يمكنك إدخال اسم الجهاز وسيتصل به عند ظهوره على الرادار.
                </div>
              ) : (
                <select
                  value={selectedDeviceId}
                  onChange={(e) => setSelectedDeviceId(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                >
                  {discoveredDevices.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.id}) - {d.rssi} dBm
                    </option>
                  ))}
                </select>
              )}
            </div>
          ) : (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  اسم الغرفة
                </label>
                <input
                  type="text"
                  placeholder="مثال: غرفة الطوارئ الميدانية"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  وصف الغرفة
                </label>
                <input
                  type="text"
                  placeholder="وصف مختصر للغرفة والغرض منها"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {/* Password Protection */}
              <div className="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-slate-800/80 border border-amber-200 dark:border-slate-700 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isPasswordProtected}
                    onChange={(e) => setIsPasswordProtected(e.target.checked)}
                    className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500 border-slate-300"
                  />
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <Lock className="w-3.5 h-3.5 text-amber-500" />
                    <span>حماية القناة برمز سري وتشفير AES-GCM إضافي</span>
                  </div>
                </label>

                {isPasswordProtected && (
                  <div className="pt-2 space-y-1 animate-fadeIn">
                    <input
                      type="password"
                      placeholder="أدخل كلمة مرور قوية لتوليد مفتاح PBKDF2"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required={isPasswordProtected}
                      className="w-full px-3 py-2 text-xs rounded-lg bg-white dark:bg-slate-900 border border-amber-300 dark:border-slate-600 text-slate-900 dark:text-white"
                    />
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      لن يتمكن أي جهاز من قراءة رسائل هذه الغرفة دون إدخال نفس الرمز السري.
                    </p>
                  </div>
                )}
              </div>
            </>
          )}

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold shadow-md transition active:scale-95"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إنشاء وبدء الاتصال</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
