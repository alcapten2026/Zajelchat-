import React, { useState } from 'react';
import { X, Lock, KeyRound, Unlock, AlertCircle } from 'lucide-react';

interface UnlockChannelModalProps {
  isOpen: boolean;
  onClose: () => void;
  channelName: string;
  expectedPassword?: string;
  onSuccess: (password: string) => void;
}

export const UnlockChannelModal: React.FC<UnlockChannelModalProps> = ({
  isOpen,
  onClose,
  channelName,
  expectedPassword,
  onSuccess,
}) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      setError('يرجى كتابة كلمة المرور.');
      return;
    }

    if (expectedPassword && password.trim() !== expectedPassword.trim()) {
      setError('كلمة المرور غير صحيحة! مفتاح AES-GCM لن يطابق تشفير الرسائل.');
      return;
    }

    setError(null);
    onSuccess(password.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-amber-200 dark:border-slate-800 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 bg-amber-50 dark:bg-slate-800/60 border-b border-amber-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center shadow-md">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-black text-slate-900 dark:text-white">
                فك قفل القناة المشفرة
              </h2>
              <p className="text-[11px] text-slate-500">{channelName}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleUnlock} className="p-5 space-y-4">
          <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            هذه الغرفة محمية بتشفير <strong>AES-256-GCM</strong>. أدخل كلمة المرور لاشتقاق مفتاح فك التشفير:
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              كلمة المرور السرية
            </label>
            <input
              type="password"
              placeholder="اكتب رمز القناة السري..."
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError(null);
              }}
              autoFocus
              className="w-full px-3.5 py-2.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {error && (
            <div className="p-2.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-600 dark:text-red-400 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow-md transition active:scale-95 cursor-pointer"
            >
              <Unlock className="w-3.5 h-3.5" />
              <span>فك التشفير</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
