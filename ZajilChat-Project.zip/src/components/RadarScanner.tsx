import React, { useState } from 'react';
import {
  X,
  Radio,
  Bluetooth,
  RefreshCw,
  ShieldAlert,
  Smartphone,
  Signal,
  CheckCircle2,
  Lock,
  ExternalLink
} from 'lucide-react';
import { BluetoothDevice } from '../types';
import { bluetoothManager } from '../services/bluetooth';

interface RadarScannerProps {
  isOpen: boolean;
  onClose: () => void;
  devices: BluetoothDevice[];
  onConnect: (device: BluetoothDevice) => void;
  onBlock: (device: BluetoothDevice) => void;
  isScanning: boolean;
  onRefreshScan: () => void;
}

export const RadarScanner: React.FC<RadarScannerProps> = ({
  isOpen,
  onClose,
  devices,
  onConnect,
  onBlock,
  isScanning,
  onRefreshScan,
}) => {
  const [hardwarePairingNotice, setHardwarePairingNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleHardwarePair = async () => {
    setHardwarePairingNotice('جاري طلب الاتصال بمستشعر البلوتوث الحقيقي في الهاتف/الحاسوب...');
    const dev = await bluetoothManager.requestHardwareBluetoothPairing();
    if (dev) {
      setHardwarePairingNotice(`تم الاقتران بنجاح مع: ${dev.name}`);
      onConnect(dev);
    } else {
      setHardwarePairingNotice('تم إلغاء الاقتران أو متصفحك لا يدعم Web Bluetooth في هذا الوضع.');
      setTimeout(() => setHardwarePairingNotice(null), 4000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-sky-100 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-sky-50 dark:bg-slate-800/60 border-b border-sky-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-sky-500 text-white flex items-center justify-center shadow-md shadow-sky-500/20">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900 dark:text-white">
                رادار كشف أجهزة البلوتوث المجاورة (RFCOMM)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                كشف إشارات البلوتوث دون إنترنت في نطاق 10 - 50 متراً
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-6">
          {/* Radar Visual Display */}
          <div className="relative w-full aspect-[2/1] sm:aspect-[2.3/1] bg-gradient-to-b from-sky-950 via-slate-900 to-sky-950 rounded-2xl overflow-hidden flex items-center justify-center border border-sky-800/40 shadow-inner">
            {/* Concentric rings */}
            <div className="absolute w-[80%] aspect-square rounded-full border border-sky-500/15"></div>
            <div className="absolute w-[60%] aspect-square rounded-full border border-sky-500/25"></div>
            <div className="absolute w-[40%] aspect-square rounded-full border border-sky-500/35"></div>
            <div className="absolute w-[20%] aspect-square rounded-full border border-sky-500/45"></div>

            {/* Crosshairs */}
            <div className="absolute inset-x-0 top-1/2 h-px bg-sky-500/20"></div>
            <div className="absolute inset-y-0 left-1/2 w-px bg-sky-500/20"></div>

            {/* Sweeping Radar Beam */}
            <div className="absolute w-full h-full rounded-full animate-spin [animation-duration:4s] pointer-events-none">
              <div className="w-1/2 h-1/2 bg-gradient-to-tr from-sky-400/25 to-transparent rounded-tl-full origin-bottom-right"></div>
            </div>

            {/* Center: Own Device */}
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-sky-500 text-white flex items-center justify-center ring-4 ring-sky-400/30 shadow-lg">
                <Bluetooth className="w-4 h-4" />
              </div>
              <span className="text-[10px] text-sky-200 font-bold mt-1 bg-slate-900/80 px-2 py-0.5 rounded-full border border-sky-700/50">
                أنت (هاتفك)
              </span>
            </div>

            {/* Plotted Devices */}
            {devices.map((device, index) => {
              // Deterministic angle based on index
              const angle = (index * 95 + 40) * (Math.PI / 180);
              // Distance radius
              const radiusPercent = Math.min(38, Math.max(15, device.distanceMeters * 4 + 10));
              const top = 50 - radiusPercent * Math.sin(angle);
              const left = 50 + radiusPercent * Math.cos(angle);

              return (
                <div
                  key={device.id}
                  style={{ top: `${top}%`, left: `${left}%` }}
                  className="absolute z-10 -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
                  onClick={() => onConnect(device)}
                >
                  <div className="relative flex items-center justify-center">
                    <span
                      className={`absolute inline-flex h-7 w-7 rounded-full opacity-60 animate-ping ${
                        device.status === 'connected' ? 'bg-emerald-400' : 'bg-sky-400'
                      }`}
                    ></span>
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-[10px] font-bold shadow-md ring-2 ${
                        device.status === 'connected'
                          ? 'bg-emerald-500 ring-emerald-300'
                          : 'bg-sky-600 ring-sky-300'
                      }`}
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                    </div>
                  </div>
                  <div className="absolute bottom-full mb-1 left-1/2 -translate-x-1/2 bg-slate-950/90 text-white text-[9px] px-2 py-0.5 rounded-md whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity border border-sky-800 pointer-events-none">
                    {device.name} ({device.rssi} dBm)
                  </div>
                </div>
              );
            })}
          </div>

          {/* Action Row */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <button
              onClick={onRefreshScan}
              disabled={isScanning}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 active:scale-95 text-white font-bold text-xs transition shadow-md disabled:opacity-60 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
              {isScanning ? 'جاري المسح الترددي...' : 'إعادة مسح البلوتوث'}
            </button>

            <button
              onClick={handleHardwarePair}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition border border-slate-200 dark:border-slate-700 cursor-pointer"
              title="اتصال مباشر عبر عتاد Web Bluetooth الحقيقي"
            >
              <ExternalLink className="w-3.5 h-3.5 text-sky-500" />
              <span>اقتران بجهاز بلوتوث حقيقي (Web Bluetooth)</span>
            </button>
          </div>

          {hardwarePairingNotice && (
            <div className="p-2.5 rounded-xl bg-sky-50 dark:bg-sky-950/50 border border-sky-200 dark:border-sky-800 text-xs text-sky-800 dark:text-sky-300 text-center animate-fadeIn">
              {hardwarePairingNotice}
            </div>
          )}

          {/* Discovered Devices List */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
              <span>الأجهزة المكتشفة ({devices.length})</span>
              <span className="text-[11px] font-normal text-slate-500">نطاق RFCOMM SPP</span>
            </h3>

            {devices.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700">
                لم يتم العثور على أجهزة بلوتوث قريبة. تأكد من تشغيل البلوتوث على الهواتف الأخرى.
              </div>
            ) : (
              <div className="space-y-2">
                {devices.map((device) => (
                  <div
                    key={device.id}
                    className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 flex items-center justify-between hover:border-sky-300 dark:hover:border-sky-700 transition shadow-sm"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
                          device.status === 'connected'
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-400'
                            : 'bg-sky-100 text-sky-700 dark:bg-sky-950/80 dark:text-sky-400'
                        }`}
                      >
                        <Smartphone className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-black text-slate-900 dark:text-white">
                            {device.name}
                          </h4>
                          {device.status === 'connected' && (
                            <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                              <CheckCircle2 className="w-3 h-3" />
                              متصل
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                          <span>MAC: {device.id}</span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Signal className="w-2.5 h-2.5 text-sky-500" />
                            {device.rssi} dBm (~{device.distanceMeters}م)
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onConnect(device)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 cursor-pointer ${
                          device.status === 'connected'
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                            : 'bg-sky-500 hover:bg-sky-600 text-white shadow-sm'
                        }`}
                      >
                        {device.status === 'connected' ? 'محادثة مباشرة' : 'اتصال مباشر'}
                      </button>

                      <button
                        onClick={() => onBlock(device)}
                        className="p-1.5 rounded-xl text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/50 transition cursor-pointer"
                        title="حظر هذا الجهاز البلوتوث"
                      >
                        <ShieldAlert className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
