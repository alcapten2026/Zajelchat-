import React from 'react';
import { X, ShieldAlert, ShieldCheck, Smartphone, Trash2 } from 'lucide-react';
import { BlockedDevice } from '../types';

interface BlockedDevicesModalProps {
  isOpen: boolean;
  onClose: () => void;
  blockedDevices: BlockedDevice[];
  onUnblock: (deviceId: string) => void;
}

export const BlockedDevicesModal: React.FC<BlockedDevicesModalProps> = ({
  isOpen,
  onClose,
  blockedDevices,
  onUnblock,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-sky-100 dark:border-slate-800 overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-red-50 dark:bg-slate-800/60 border-b border-red-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-red-500 text-white flex items-center justify-center shadow-md">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900 dark:text-white">
                الأجهزة المحظورة ({blockedDevices.length})
              </h2>
              <p className="text-[11px] text-slate-500">
                يتم إسقاط وتجاهل أي رسالة بلوتوث قادمة من هذه الأجهزة فورياً
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-3">
          {blockedDevices.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              <ShieldCheck className="w-10 h-10 text-emerald-500 mx-auto mb-2 opacity-80" />
              <p className="font-bold text-slate-600 dark:text-slate-300">
                لا توجد أي أجهزة محظورة حالياً.
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                يمكنك حظر أي جهاز عبر الرادار أو من داخل المحادثة الخاصة به.
              </p>
            </div>
          ) : (
            blockedDevices.map((device) => (
              <div
                key={device.id}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-red-100 text-red-600 dark:bg-red-950/80 dark:text-red-400 flex items-center justify-center">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      {device.name}
                    </h4>
                    <p className="text-[10px] font-mono text-slate-500 dark:text-slate-400">
                      MAC: {device.id}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => onUnblock(device.id)}
                  className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  إلغاء الحظر
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 text-white dark:bg-slate-700 text-xs font-bold transition"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
