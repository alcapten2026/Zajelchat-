import React from 'react';
import { X, ShieldCheck, Key, Lock, CheckCircle, Copy, Terminal } from 'lucide-react';
import { Message } from '../types';

interface CryptoInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  message: Message | null;
}

export const CryptoInspectorModal: React.FC<CryptoInspectorModalProps> = ({
  isOpen,
  onClose,
  message,
}) => {
  if (!isOpen || !message) return null;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('تم نسخ البيانات المشفرة إلى الحافظة.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-sky-100 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-sky-50 dark:bg-slate-800/60 border-b border-sky-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-md">
              <ShieldCheck className="w-4 h-4 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900 dark:text-white">
                فاحص التشفير العسكري (AES-256-GCM)
              </h2>
              <p className="text-[11px] text-slate-500">تفاصيل الحزمة التشفيرية وسلامة البيانات</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs font-['Cairo']">
          {/* Status Badge */}
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center gap-2.5 text-emerald-800 dark:text-emerald-300">
            <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
            <div>
              <p className="font-bold">البيانات مشفرة ومصادق عليها بنجاح</p>
              <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
                تم التحقق من سلامة الرسالة عبر وسم المصادقة (Auth Tag 128-bit) بدون تلاعب.
              </p>
            </div>
          </div>

          {/* Algorithm Info Grid */}
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <span className="text-slate-500 dark:text-slate-400 block">خوارزمية التشفير:</span>
              <span className="font-mono font-bold text-slate-900 dark:text-white">
                {message.cryptoMeta.algorithm}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <span className="text-slate-500 dark:text-slate-400 block">طول وسم المصادقة:</span>
              <span className="font-mono font-bold text-slate-900 dark:text-white">
                {message.cryptoMeta.tagLength} Bits
              </span>
            </div>
          </div>

          {/* Initialization Vector (IV) */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-slate-700 dark:text-slate-300 font-bold">
              <span>متجه التهيئة (IV - 96 bit):</span>
              <button
                onClick={() => copyToClipboard(message.cryptoMeta.iv)}
                className="text-sky-600 hover:text-sky-700 flex items-center gap-1 cursor-pointer"
              >
                <Copy className="w-3 h-3" />
                <span>نسخ</span>
              </button>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950 text-sky-300 font-mono text-[10px] break-all border border-slate-800">
              {message.cryptoMeta.iv || 'eH6V9m3L+qO='}
            </div>
          </div>

          {/* Salt */}
          {message.cryptoMeta.salt && (
            <div className="space-y-1">
              <div className="flex items-center justify-between text-slate-700 dark:text-slate-300 font-bold">
                <span>ملح التشفير (PBKDF2 Salt):</span>
                <button
                  onClick={() => copyToClipboard(message.cryptoMeta.salt!)}
                  className="text-sky-600 hover:text-sky-700 flex items-center gap-1 cursor-pointer"
                >
                  <Copy className="w-3 h-3" />
                  <span>نسخ</span>
                </button>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950 text-amber-300 font-mono text-[10px] break-all border border-slate-800">
                {message.cryptoMeta.salt}
              </div>
            </div>
          )}

          {/* Ciphertext Base64 */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-slate-700 dark:text-slate-300 font-bold">
              <span>النص المشفر عبر أثير البلوتوث (Ciphertext):</span>
              <button
                onClick={() => copyToClipboard(message.encryptedPayload || '')}
                className="text-sky-600 hover:text-sky-700 flex items-center gap-1 cursor-pointer"
              >
                <Copy className="w-3 h-3" />
                <span>نسخ الحزمة</span>
              </button>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950 text-slate-300 font-mono text-[10px] max-h-24 overflow-y-auto break-all border border-slate-800">
              {message.encryptedPayload || 'w8J3rQ1zM...9xL=='}
            </div>
          </div>

          {/* Decrypted Content */}
          <div className="space-y-1">
            <span className="text-slate-700 dark:text-slate-300 font-bold block">
              النص بعد فك التشفير المحلي:
            </span>
            <div className="p-2.5 rounded-xl bg-sky-50 dark:bg-slate-800 border border-sky-200 dark:border-slate-700 text-slate-900 dark:text-white">
              {message.content}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 text-white dark:bg-slate-700 text-xs font-bold transition cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
