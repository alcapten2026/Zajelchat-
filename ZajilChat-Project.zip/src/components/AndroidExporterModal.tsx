import React, { useState } from 'react';
import {
  X,
  Download,
  FileCode,
  CheckCircle,
  Copy,
  ExternalLink,
  Smartphone,
  Layers,
  Terminal,
  Cpu,
  Shield,
  HelpCircle
} from 'lucide-react';
import { getAndroidProjectFiles, downloadAndroidProjectZip, AndroidFileItem } from '../services/androidProjectGenerator';

interface AndroidExporterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidExporterModal: React.FC<AndroidExporterModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [files] = useState<AndroidFileItem[]>(getAndroidProjectFiles());
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentFile = files[selectedFileIndex] || files[0];

  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      await downloadAndroidProjectZip();
    } catch (e) {
      console.error('Failed to create zip', e);
      alert('حدث خطأ أثناء تصدير ملف ZIP. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/80 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-5xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-sky-100 dark:border-slate-800 overflow-hidden flex flex-col h-[94vh]">
        {/* Modal Top Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-sky-600 to-sky-700 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white p-1 shadow flex items-center justify-center">
              <img
                src="/assets/aistudio/a_clean_high_resolution_isolated_illustration_gra_ed286f78.png"
                alt="شعار زاجل شات"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black font-['Cairo']">
                  سورس كود أندرويد الأصلي (Native Kotlin Project)
                </h2>
                <span className="text-[10px] bg-amber-400 text-slate-950 font-black px-2 py-0.5 rounded-full">
                  100% Native - بدون WebView
                </span>
              </div>
              <p className="text-xs text-sky-100 font-medium">
                تطوير: سلامة تكنولوجي • م/ بسام عبدالرقيب الشميري
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={isExporting}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow-lg transition active:scale-95 cursor-pointer disabled:opacity-60"
            >
              <Download className="w-4 h-4 text-slate-950" />
              <span>{isExporting ? 'جاري التحزيم...' : 'تحميل مشروع أندرويد (ZIP)'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Instructions Banner */}
        <div className="bg-sky-50 dark:bg-slate-800/80 px-5 py-3 border-b border-sky-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
            <Smartphone className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
            <span>
              <strong>طريقة بناء APK مجاناً:</strong> ارفع المشروع إلى مستودع GitHub مجاني وسيقوم <strong>GitHub Actions</strong> ببناء ملف <code className="bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded font-mono text-[11px]">app-debug.apk</code> تلقائياً وتنزيله فوراً!
            </span>
          </div>

          <span className="text-[11px] text-sky-700 dark:text-sky-300 font-bold bg-sky-100 dark:bg-sky-950 px-2.5 py-1 rounded-lg">
            RFCOMM Bluetooth Sockets + AES-256-GCM
          </span>
        </div>

        {/* Main Body: File Selector & Code Preview */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
          {/* File Tree List */}
          <div className="w-full md:w-72 bg-slate-50 dark:bg-slate-950/60 border-b md:border-b-0 md:border-l border-slate-200 dark:border-slate-800 overflow-y-auto p-3 space-y-1.5">
            <h3 className="text-xs font-bold text-slate-400 px-2 py-1">
              ملفات المشروع الأصلي ({files.length})
            </h3>
            {files.map((file, idx) => {
              const isSelected = idx === selectedFileIndex;
              const fileName = file.path.split('/').pop();
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFileIndex(idx)}
                  className={`w-full text-right p-2.5 rounded-xl text-xs transition flex items-center justify-between gap-2 cursor-pointer ${
                    isSelected
                      ? 'bg-sky-500 text-white font-bold shadow-sm'
                      : 'hover:bg-slate-200/60 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-white' : 'text-sky-500'}`} />
                    <span className="truncate font-mono text-[11px]">{fileName}</span>
                  </div>
                  <span className="text-[9px] opacity-75 shrink-0 uppercase font-mono">
                    {file.language}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Code Viewer Panel */}
          <div className="flex-1 flex flex-col min-h-0 bg-slate-950 text-slate-100 overflow-hidden">
            {/* Viewer Header */}
            <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-sky-400 font-bold">
                  {currentFile.path}
                </span>
                <span className="text-[11px] text-slate-400">
                  — {currentFile.description}
                </span>
              </div>

              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-bold transition cursor-pointer"
              >
                {copied ? (
                  <>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span>تم النسخ!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>نسخ الكود</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Content */}
            <pre className="flex-1 overflow-auto p-4 text-[11px] sm:text-xs font-mono leading-relaxed text-slate-200 selection:bg-sky-500 selection:text-white" dir="ltr">
              <code>{currentFile.content}</code>
            </pre>
          </div>
        </div>

        {/* Modal Bottom Footer */}
        <div className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
            <span className="font-bold text-slate-900 dark:text-white">سلامة تكنولوجي</span>
            <span>•</span>
            <span>م/ بسام عبدالرقيب الشميري</span>
            <span>•</span>
            <span className="text-[11px]">جاهز للبناء على Android Studio Koala / Hedgehog أو GitHub Actions</span>
          </div>

          <button
            onClick={handleDownloadZip}
            disabled={isExporting}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold transition shadow-sm cursor-pointer disabled:opacity-60"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تنزيل السورس كود كاملاً (ZIP)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
