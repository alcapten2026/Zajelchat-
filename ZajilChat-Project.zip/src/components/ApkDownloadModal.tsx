import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  Smartphone,
  CheckCircle,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  Layers,
  ArrowDownToLine,
  HelpCircle,
  Terminal,
  Share2
} from 'lucide-react';
import { downloadAndroidProjectZip } from '../services/androidProjectGenerator';

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSourceModal: () => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({
  isOpen,
  onClose,
  onOpenSourceModal,
}) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [isExportingZip, setIsExportingZip] = useState(false);

  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  if (!isOpen) return null;

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstallable(false);
      }
    } else {
      alert('لتثبيت التطبيق على هاتفك: افتح قائمة خيارات المتصفح (⋮) ثم اضغط على "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية" ليظهر كتطبيق أندرويد مستقل!');
    }
  };

  const handleDownloadZip = async () => {
    setIsExportingZip(true);
    try {
      await downloadAndroidProjectZip();
    } catch (e) {
      console.error(e);
    } finally {
      setIsExportingZip(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-sky-100 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-sky-500 to-sky-600 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white p-1 shadow flex items-center justify-center ring-2 ring-white/30">
              <img
                src="/assets/aistudio/a_clean_high_resolution_isolated_illustration_gra_ed286f78.png"
                alt="زاجل شات"
                className="w-full h-full object-contain filter drop-shadow"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black font-['Cairo']">
                  تحميل تطبيق زاجل شات (Android APK)
                </h2>
                <span className="text-[10px] bg-amber-400 text-slate-950 font-black px-2 py-0.5 rounded-full">
                  جاهز للتثبيت
                </span>
              </div>
              <p className="text-xs text-sky-100 font-medium">
                تطوير: سلامة تكنولوجي • م/ بسام عبدالرقيب الشميري
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Card 1: Direct APK Download */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-sky-50 to-blue-50 dark:from-slate-800 dark:to-slate-800/60 border border-sky-200 dark:border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xs">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-12 h-12 rounded-2xl bg-sky-500 text-white flex items-center justify-center shrink-0 shadow-md">
                <ArrowDownToLine className="w-6 h-6 animate-bounce" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <span>تحميل ملف APK المباشر (ZajilChat-Android.apk)</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  حزمة التثبيت المباشرة لهواتف أندرويد جاهزة للتنزيل الفوري
                </p>
                <div className="flex items-center gap-2 mt-1 text-[11px] font-mono text-sky-600 dark:text-sky-400 font-bold">
                  <span>الحجم: ~1.2 ميغابايت</span>
                  <span>•</span>
                  <span>الإصدار: v1.0.0</span>
                </div>
              </div>
            </div>

            <a
              href="/ZajilChat-Android.apk"
              download="ZajilChat-Android.apk"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black text-xs transition shadow-md active:scale-95 cursor-pointer shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>تحميل ملف APK الآن</span>
            </a>
          </div>

          {/* Card 2: 1-Tap Android Direct Install (WebAPK) */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-md">
                <Smartphone className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <span>تثبيت فوري على هاتف أندرويد (تطبيق أصلي WebAPK)</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  يتثبت مباشرة على هاتفك مع أيقونة الزاجل الذهبي وشاشة البداية ويعمل أوفلاين
                </p>
              </div>
            </div>

            <button
              onClick={handleInstallPWA}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs transition shadow-md active:scale-95 cursor-pointer shrink-0"
            >
              <CheckCircle className="w-4 h-4" />
              <span>تثبيت التطبيق على الهاتف</span>
            </button>
          </div>

          {/* Card 3: Free Cloud Build with GitHub Actions */}
          <div className="p-4 rounded-2xl bg-amber-50/70 dark:bg-slate-800/50 border border-amber-200 dark:border-slate-700 space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 shadow-sm font-bold">
                  <Terminal className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white">
                    البناء السحابي التلقائي مجاناً 100% (GitHub Actions)
                  </h3>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400">
                    يبني لك حزمة Kotlin الأصلية مع مآخذ RFCOMM البلوتوث وتشفير AES-GCM تلقائياً
                  </p>
                </div>
              </div>

              <button
                onClick={handleDownloadZip}
                disabled={isExportingZip}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 dark:bg-slate-700 text-xs font-bold transition shadow-xs cursor-pointer shrink-0"
              >
                <Download className="w-3.5 h-3.5 text-amber-300" />
                <span>{isExportingZip ? 'جاري التحزيم...' : 'تنزيل السورس كود (ZIP)'}</span>
              </button>
            </div>

            <ol className="list-decimal list-inside text-xs space-y-1 text-slate-700 dark:text-slate-300 bg-white/70 dark:bg-slate-900/60 p-3 rounded-xl border border-amber-200/60 dark:border-slate-700">
              <li>حمل ملف السورس كود <strong>ZajilChat-Native-Android-Source.zip</strong>.</li>
              <li>أنشئ مستودعاً مجانياً على GitHub وارفع الملفات إليه.</li>
              <li>سيقوم ملف <code className="font-mono text-amber-700 dark:text-amber-400 font-bold">.github/workflows/build-apk.yml</code> ببناء ملف <code className="font-mono font-bold">app-debug.apk</code> تلقائياً وتحميله مجاناً!</li>
            </ol>
          </div>

          {/* Developer Card */}
          <div className="p-3.5 rounded-2xl bg-sky-50 dark:bg-slate-800/80 border border-sky-100 dark:border-slate-700 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2.5">
              <img
                src="/assets/aistudio/a_clean_high_resolution_isolated_illustration_gra_ed286f78.png"
                alt="شعار المطور"
                className="w-7 h-7 object-contain"
              />
              <div>
                <span className="font-bold text-slate-900 dark:text-white">سلامة تكنولوجي</span>
                <span className="mx-1 text-slate-400">•</span>
                <span className="text-slate-600 dark:text-slate-300 font-medium">م/ بسام عبدالرقيب الشميري</span>
              </div>
            </div>

            <button
              onClick={() => {
                onClose();
                onOpenSourceModal();
              }}
              className="text-sky-600 dark:text-sky-400 font-bold hover:underline cursor-pointer flex items-center gap-1"
            >
              <span>معاينة كود Kotlin الأصلي</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-slate-800 text-white dark:bg-slate-700 text-xs font-bold transition cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
