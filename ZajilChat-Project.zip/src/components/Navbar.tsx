import React from 'react';
import {
  Radio,
  Download,
  Moon,
  Sun,
  Shield,
  User,
  Bluetooth,
  Smartphone,
  Info
} from 'lucide-react';
import { UserProfile } from '../types';

interface NavbarProps {
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenRadar: () => void;
  onOpenExporter: () => void;
  onOpenApkModal: () => void;
  onOpenProfile: () => void;
  onOpenBlocked: () => void;
  onOpenAbout: () => void;
  activeDeviceCount: number;
  profile: UserProfile;
}

export const Navbar: React.FC<NavbarProps> = ({
  darkMode,
  onToggleDarkMode,
  onOpenRadar,
  onOpenExporter,
  onOpenApkModal,
  onOpenProfile,
  onOpenBlocked,
  onOpenAbout,
  activeDeviceCount,
  profile,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-sky-500 text-white dark:bg-slate-900 border-b border-sky-400 dark:border-slate-800 shadow-md transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2">
        {/* Logo and App Title */}
        <div className="flex items-center gap-3">
          <div className="relative group cursor-pointer" onClick={onOpenAbout} title="معلومات عن زاجل شات">
            <div className="w-11 h-11 rounded-2xl bg-white p-1 shadow-inner flex items-center justify-center overflow-hidden ring-2 ring-white/30 dark:ring-sky-500/50 transition-transform group-hover:scale-105">
              <img
                src="/assets/aistudio/a_clean_high_resolution_isolated_illustration_gra_ed286f78.png"
                alt="زاجل شات - أيقونة التطبيق"
                className="w-full h-full object-contain filter drop-shadow"
              />
            </div>
            <span className="absolute -bottom-1 -right-1 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 ring-2 ring-white dark:ring-slate-900"></span>
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black tracking-tight font-['Cairo'] text-white">
                زاجل شات
              </h1>
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold bg-sky-600/60 dark:bg-sky-950/80 text-sky-100 dark:text-sky-300 px-2 py-0.5 rounded-full border border-sky-400/40 dark:border-sky-800">
                <Bluetooth className="w-3 h-3 text-sky-200" />
                بلوتوث أوفلاين
              </span>
            </div>
            {/* Developer Attribution requested by User */}
            <div className="text-[11px] font-medium text-sky-100/90 dark:text-slate-400 flex items-center gap-1 truncate max-w-[200px] sm:max-w-xs">
              <span className="text-amber-300 font-bold">تطوير:</span>
              <span>سلامة تكنولوجي</span>
              <span className="opacity-60">•</span>
              <span className="text-white font-semibold dark:text-sky-300">م/ بسام عبدالرقيب الشميري</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Radar Scanner Button */}
          <button
            onClick={onOpenRadar}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 active:scale-95 transition-all text-xs font-bold border border-white/20 backdrop-blur-sm cursor-pointer shadow-sm"
            title="رادار كشف أجهزة البلوتوث المحيطة"
          >
            <Radio className="w-4 h-4 text-emerald-300 animate-pulse" />
            <span className="hidden md:inline">رادار البلوتوث</span>
            <span className="bg-emerald-400 text-emerald-950 text-[10px] font-extrabold px-1.5 py-0.2 rounded-full">
              {activeDeviceCount}
            </span>
          </button>

          {/* APK Direct Download & Install Modal */}
          <button
            onClick={onOpenApkModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 active:scale-95 transition-all text-xs font-black shadow-md border border-amber-300 cursor-pointer animate-pulse"
            title="تحميل وتثبيت ملف APK لهواتف أندرويد"
          >
            <Smartphone className="w-4 h-4 text-slate-950" />
            <span>تحميل APK</span>
          </button>

          {/* Android Native Source Export */}
          <button
            onClick={onOpenExporter}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white active:scale-95 transition-all text-xs font-bold shadow-xs border border-white/20 cursor-pointer"
            title="تصدير سورس كود أندرويد الأصلي"
          >
            <Download className="w-3.5 h-3.5" />
            <span>سورس كود أندرويد</span>
          </button>

          {/* Blocked Devices Button */}
          <button
            onClick={onOpenBlocked}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 transition-all text-white text-xs cursor-pointer border border-white/10"
            title="الأجهزة المحظورة"
          >
            <Shield className="w-4 h-4" />
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 transition-all text-white text-xs cursor-pointer border border-white/10"
            title={darkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-sky-100" />}
          </button>

          {/* Profile Button */}
          <button
            onClick={onOpenProfile}
            className="flex items-center gap-2 pl-2 pr-1 py-1 rounded-xl bg-white/15 hover:bg-white/25 active:scale-95 transition-all border border-white/20 cursor-pointer"
            title="الملف الشخصي وإعدادات الجهاز"
          >
            <div className="w-7 h-7 rounded-lg bg-sky-100 text-sky-800 flex items-center justify-center text-sm font-bold shadow-sm">
              {profile.avatar || '🕊️'}
            </div>
            <span className="text-xs font-bold hidden lg:inline max-w-[80px] truncate">
              {profile.name}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
