import React, { useState } from 'react';
import {
  Search,
  Plus,
  Users,
  Lock,
  MessageSquare,
  ShieldAlert,
  Smartphone,
  ChevronLeft,
  KeyRound,
  FileText,
  Mic,
  Image as ImageIcon
} from 'lucide-react';
import { Conversation } from '../types';

interface SidebarProps {
  conversations: Conversation[];
  activeId: string | null;
  onSelectConversation: (id: string) => void;
  onOpenNewModal: (type: 'direct' | 'group') => void;
  onOpenBlocked: () => void;
  onOpenAbout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  conversations,
  activeId,
  onSelectConversation,
  onOpenNewModal,
  onOpenBlocked,
  onOpenAbout,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'direct' | 'group'>('all');

  const filteredConversations = conversations.filter((c) => {
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.description && c.description.toLowerCase().includes(searchQuery.toLowerCase()));
    if (!matchesSearch) return false;
    if (filterType === 'all') return true;
    return c.type === filterType;
  });

  const formatTime = (time?: number) => {
    if (!time) return '';
    const date = new Date(time);
    return date.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <aside className="w-full md:w-80 lg:w-96 bg-white dark:bg-slate-900 border-l border-sky-100 dark:border-slate-800 flex flex-col h-full select-none transition-colors">
      {/* Top Search & Actions */}
      <div className="p-3.5 space-y-3 border-b border-sky-100 dark:border-slate-800 bg-sky-50/50 dark:bg-slate-900/60">
        <div className="relative">
          <input
            type="text"
            placeholder="بحث في المحادثات والغرف..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pr-9 pl-4 py-2 text-xs rounded-xl bg-white dark:bg-slate-800 border border-sky-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5 pointer-events-none" />
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1 p-1 bg-sky-100/60 dark:bg-slate-800/80 rounded-xl">
          <button
            onClick={() => setFilterType('all')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
              filterType === 'all'
                ? 'bg-white dark:bg-sky-600 text-sky-700 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            الكل ({conversations.length})
          </button>
          <button
            onClick={() => setFilterType('direct')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
              filterType === 'direct'
                ? 'bg-white dark:bg-sky-600 text-sky-700 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            خاصة P2P
          </button>
          <button
            onClick={() => setFilterType('group')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
              filterType === 'group'
                ? 'bg-white dark:bg-sky-600 text-sky-700 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            غرف Mesh
          </button>
        </div>

        {/* Create Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => onOpenNewModal('direct')}
            className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 active:scale-95 text-white font-bold text-xs transition shadow-sm cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>محادثة خاصة</span>
          </button>
          <button
            onClick={() => onOpenNewModal('group')}
            className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 active:scale-95 text-white font-bold text-xs transition shadow-sm cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-amber-300" />
            <span>غرفة مشفرة</span>
          </button>
        </div>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto divide-y divide-sky-50 dark:divide-slate-800/60">
        {filteredConversations.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            لا توجد محادثات تطابق بحثك. أنشئ محادثة جديدة أو امسح البلوتوث.
          </div>
        ) : (
          filteredConversations.map((conv) => {
            const isSelected = conv.id === activeId;
            return (
              <div
                key={conv.id}
                onClick={() => onSelectConversation(conv.id)}
                className={`p-3.5 flex items-center justify-between gap-3 cursor-pointer transition-colors relative ${
                  isSelected
                    ? 'bg-sky-100/70 dark:bg-sky-950/40 border-r-4 border-sky-500'
                    : 'hover:bg-sky-50/60 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <div className="w-12 h-12 rounded-2xl bg-sky-100 dark:bg-slate-800 border border-sky-200 dark:border-slate-700 flex items-center justify-center text-xl shadow-xs">
                      {conv.avatar || (conv.type === 'group' ? '👥' : '📱')}
                    </div>
                    {conv.isPasswordProtected && (
                      <div
                        className="absolute -bottom-1 -left-1 w-5 h-5 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-sm"
                        title="قناة محمية بكلمة مرور وتشفير AES-GCM"
                      >
                        <KeyRound className="w-2.5 h-2.5" />
                      </div>
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <h3 className="text-xs font-black text-slate-900 dark:text-white truncate">
                        {conv.name}
                      </h3>
                      {conv.lastMessageTime && (
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 shrink-0">
                          {formatTime(conv.lastMessageTime)}
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {conv.lastMessage || conv.description || 'لا توجد رسائل سابقة'}
                    </p>

                    <div className="flex items-center gap-2 mt-1">
                      {conv.type === 'group' ? (
                        <span className="text-[9px] font-bold text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/60 px-1.5 py-0.2 rounded">
                          شبكة جماعية
                        </span>
                      ) : (
                        <span className="text-[9px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.2 rounded">
                          بلوتوث P2P
                        </span>
                      )}

                      {conv.isPasswordProtected && (
                        <span className="text-[9px] font-semibold text-amber-600 dark:text-amber-400">
                          AES-256 مشفر
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {conv.unreadCount > 0 && (
                  <span className="shrink-0 w-5 h-5 rounded-full bg-sky-500 text-white text-[10px] font-extrabold flex items-center justify-center shadow-xs">
                    {conv.unreadCount}
                  </span>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Footer Branding requested by User */}
      <div
        onClick={onOpenAbout}
        className="p-3 border-t border-sky-100 dark:border-slate-800 bg-sky-50/40 dark:bg-slate-900/80 flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-400 hover:bg-sky-100/50 dark:hover:bg-slate-800 cursor-pointer transition"
      >
        <div className="flex items-center gap-2">
          <img
            src="/assets/aistudio/a_clean_high_resolution_isolated_illustration_gra_ed286f78.png"
            alt="زاجل"
            className="w-5 h-5 object-contain"
          />
          <div>
            <span className="font-bold text-slate-800 dark:text-slate-200">سلامة تكنولوجي</span>
            <span className="mx-1 text-slate-400">•</span>
            <span>م/ بسام الشميري</span>
          </div>
        </div>
        <ChevronLeft className="w-4 h-4 text-slate-400" />
      </div>
    </aside>
  );
};
