import React, { useState, useRef } from 'react';
import {
  Send,
  Paperclip,
  Mic,
  Square,
  Image as ImageIcon,
  FileText,
  Video,
  X,
  Lock,
  Smile
} from 'lucide-react';
import { MessageType } from '../types';

interface MessageInputProps {
  onSendMessage: (
    content: string,
    type: MessageType,
    fileData?: { name: string; size: number; mimeType: string; dataUrl: string; duration?: number }
  ) => void;
  isLocked: boolean;
  onPromptUnlock: () => void;
  disabled?: boolean;
}

export const MessageInput: React.FC<MessageInputProps> = ({
  onSendMessage,
  isLocked,
  onPromptUnlock,
  disabled = false,
}) => {
  const [text, setText] = useState('');
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<any>(null);

  const handleSendText = () => {
    if (isLocked) {
      onPromptUnlock();
      return;
    }
    if (!text.trim()) return;
    onSendMessage(text.trim(), 'text');
    setText('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendText();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, intendedType: MessageType) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (isLocked) {
      onPromptUnlock();
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      onSendMessage(file.name, intendedType, {
        name: file.name,
        size: file.size,
        mimeType: file.type || 'application/octet-stream',
        dataUrl,
      });
      setShowAttachMenu(false);
    };
    reader.readAsDataURL(file);

    // reset
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Start real microphone voice note recording
  const startRecording = async () => {
    if (isLocked) {
      onPromptUnlock();
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onload = () => {
          const dataUrl = reader.result as string;
          onSendMessage('ملاحظة صوتية زاجل', 'audio', {
            name: `صوت_${Date.now()}.webm`,
            size: audioBlob.size,
            mimeType: 'audio/webm',
            dataUrl,
            duration: recordingSeconds,
          });
        };
        reader.readAsDataURL(audioBlob);

        // Stop all audio tracks
        stream.getTracks().forEach((track) => track.stop());
      };

      recorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);

      recordTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Microphone access denied or error:', err);
      alert('يرجى منح إذن استخدام الميكروفون لتسجيل الملاحظات الصوتية.');
    }
  };

  const stopRecording = (shouldSend: boolean) => {
    if (recordTimerRef.current) clearInterval(recordTimerRef.current);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      if (!shouldSend) {
        // Discard
        mediaRecorderRef.current.ondataavailable = null;
        mediaRecorderRef.current.onstop = null;
        mediaRecorderRef.current.stop();
      } else {
        mediaRecorderRef.current.stop();
      }
    }
    setIsRecording(false);
    setRecordingSeconds(0);
  };

  const formatTimer = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (isLocked) {
    return (
      <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border-t border-amber-200 dark:border-amber-900/60 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-300">
          <Lock className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          <span>هذه القناة مشفرة بكلمة مرور. يرجى إدخال الرمز السري للإرسال والقراءة.</span>
        </div>
        <button
          onClick={onPromptUnlock}
          className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-900 font-black text-xs transition shadow-sm cursor-pointer"
        >
          فك القفل الآن
        </button>
      </div>
    );
  }

  return (
    <div className="p-3 bg-white dark:bg-slate-900 border-t border-sky-100 dark:border-slate-800 relative">
      {/* Attachment Menu Popup */}
      {showAttachMenu && (
        <div className="absolute bottom-16 right-4 z-20 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-sky-200 dark:border-slate-700 p-2.5 grid grid-cols-3 gap-2 w-72 animate-fadeIn">
          <label className="flex flex-col items-center gap-1.5 p-3 rounded-xl hover:bg-sky-50 dark:hover:bg-slate-700/60 cursor-pointer transition">
            <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <ImageIcon className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">صورة</span>
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => handleFileSelect(e, 'image')}
            />
          </label>

          <label className="flex flex-col items-center gap-1.5 p-3 rounded-xl hover:bg-sky-50 dark:hover:bg-slate-700/60 cursor-pointer transition">
            <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">مستند</span>
            <input
              type="file"
              accept=".pdf,.doc,.docx,.txt,.zip"
              className="hidden"
              onChange={(e) => handleFileSelect(e, 'file')}
            />
          </label>

          <label className="flex flex-col items-center gap-1.5 p-3 rounded-xl hover:bg-sky-50 dark:hover:bg-slate-700/60 cursor-pointer transition">
            <div className="w-10 h-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center">
              <Video className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">فيديو</span>
            <input
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => handleFileSelect(e, 'video')}
            />
          </label>
        </div>
      )}

      {/* Voice Recording Active Bar */}
      {isRecording ? (
        <div className="flex items-center justify-between gap-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl px-4 py-2.5 animate-pulse">
          <div className="flex items-center gap-2.5">
            <span className="w-3 h-3 rounded-full bg-red-600 animate-ping"></span>
            <span className="text-xs font-black text-red-600 dark:text-red-400">
              جاري تسجيل ملاحظة صوتية ({formatTimer(recordingSeconds)})
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => stopRecording(false)}
              className="p-1.5 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white rounded-lg transition"
              title="إلغاء التسجيل"
            >
              <X className="w-5 h-5" />
            </button>
            <button
              onClick={() => stopRecording(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md transition"
            >
              <Send className="w-3.5 h-3.5" />
              <span>إرسال الصوت</span>
            </button>
          </div>
        </div>
      ) : (
        /* Normal Input Bar */
        <div className="flex items-center gap-2">
          {/* Attach Button */}
          <button
            onClick={() => setShowAttachMenu(!showAttachMenu)}
            className={`p-2.5 rounded-xl transition cursor-pointer ${
              showAttachMenu
                ? 'bg-sky-500 text-white'
                : 'text-slate-500 dark:text-slate-400 hover:bg-sky-50 dark:hover:bg-slate-800 hover:text-sky-600'
            }`}
            title="إرفاق صورة، مستند، أو فيديو"
          >
            <Paperclip className="w-5 h-5 rotate-45" />
          </button>

          {/* Text Input */}
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="اكتب رسالة مشفرة بـ AES-256-GCM..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={disabled}
              className="w-full px-4 py-2.5 text-xs sm:text-sm rounded-2xl bg-sky-50/60 dark:bg-slate-800 border border-sky-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition"
            />
          </div>

          {/* Voice Record Button */}
          {text.trim() === '' ? (
            <button
              onClick={startRecording}
              className="p-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 active:scale-95 text-white transition shadow-sm cursor-pointer"
              title="تسجيل ملاحظة صوتية"
            >
              <Mic className="w-5 h-5" />
            </button>
          ) : (
            /* Send Button */
            <button
              onClick={handleSendText}
              className="p-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 active:scale-95 text-white transition shadow-md cursor-pointer"
              title="إرسال"
            >
              <Send className="w-5 h-5 rotate-180" />
            </button>
          )}
        </div>
      )}
    </div>
  );
};
