import React from 'react';
import { X, ShieldCheck, Bluetooth, Lock, Smartphone, Heart, Sparkles, CheckCircle2 } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-sky-100 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="relative px-6 pt-8 pb-6 bg-gradient-to-br from-sky-400 via-sky-500 to-sky-600 text-white flex flex-col items-center text-center">
          <button
            onClick={onClose}
            className="absolute top-4 left-4 p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-20 h-20 rounded-3xl bg-white p-2 shadow-2xl flex items-center justify-center mb-3 ring-4 ring-white/30">
            <img
              src="/assets/aistudio/a_clean_high_resolution_isolated_illustration_gra_ed286f78.png"
              alt="أيقونة زاجل شات"
              className="w-full h-full object-contain filter drop-shadow"
            />
          </div>

          <h2 className="text-2xl font-black font-['Cairo'] tracking-tight">
            زاجل شات (Zajil Chat)
          </h2>
          <p className="text-xs text-sky-100 mt-1 max-w-sm">
            تطبيق المراسلة الأوفلاين المشفر عبر البلوتوث المباشر بين هواتف أندرويد
          </p>

          {/* Developer Badge */}
          <div className="mt-4 px-4 py-1.5 rounded-full bg-slate-950/40 backdrop-blur-md border border-white/20 text-xs flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span className="font-bold text-amber-300">تطوير: سلامة تكنولوجي</span>
            <span>•</span>
            <span className="font-semibold text-white">م/ بسام عبدالرقيب الشميري</span>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs leading-relaxed text-slate-700 dark:text-slate-300">
          <div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-1.5 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-sky-500" />
              <span>فلسفة التطبيق والأمان:</span>
            </h3>
            <p className="text-slate-600 dark:text-slate-400">
              صُمم «زاجل شات» ليعمل في أحلك الظروف (انقطاع الإنترنت، الكوارث، الرحلات الميدانية، والمناطق النائية) معتمداً على بروتوكول البلوتوث المباشر (RFCOMM Sockets) دون وسيط، مع تشفير AES-256-GCM عسكري يمنع أي طرف ثالث من قراءة بياناتك أو التنصت عليها.
            </p>
          </div>

          <div className="space-y-2">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              المميزات الرئيسية:
            </h3>
            <ul className="grid grid-cols-1 gap-2">
              <li className="flex items-center gap-2 p-2 rounded-xl bg-sky-50 dark:bg-slate-800 border border-sky-100 dark:border-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>اتصال بلوتوث مباشر (P2P Mesh) دون إنترنت ولا سيم كارت.</span>
              </li>
              <li className="flex items-center gap-2 p-2 rounded-xl bg-sky-50 dark:bg-slate-800 border border-sky-100 dark:border-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>تشفير AES-256-GCM وقنوات محمية برمز سري واشتقاق PBKDF2.</span>
              </li>
              <li className="flex items-center gap-2 p-2 rounded-xl bg-sky-50 dark:bg-slate-800 border border-sky-100 dark:border-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>إرسال الصور والمستندات والتسجيلات الصوتية الحية والفيديو.</span>
              </li>
              <li className="flex items-center gap-2 p-2 rounded-xl bg-sky-50 dark:bg-slate-800 border border-sky-100 dark:border-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>حفظ الرسائل والوسائط محلياً 100% داخل ذاكرة الهاتف (Offline).</span>
              </li>
              <li className="flex items-center gap-2 p-2 rounded-xl bg-sky-50 dark:bg-slate-800 border border-sky-100 dark:border-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>حظر الأجهزة غير المرغوبة وإسقاط رسائلها فورياً.</span>
              </li>
              <li className="flex items-center gap-2 p-2 rounded-xl bg-sky-50 dark:bg-slate-800 border border-sky-100 dark:border-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>تصدير سورس كود أندرويد الأصلي (Kotlin) وبناء APK مجاناً.</span>
              </li>
            </ul>
          </div>

          {/* Credits box */}
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-slate-800/80 border border-amber-200 dark:border-slate-700 text-center space-y-1">
            <p className="font-black text-slate-900 dark:text-white">
              برمجة وتطوير: شركة سلامة تكنولوجي
            </p>
            <p className="text-amber-800 dark:text-amber-300 font-bold">
              المهندس / بسام عبدالرقيب الشميري
            </p>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">
              جميع الحقوق محفوظة © {new Date().getFullYear()}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold transition shadow-sm cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
