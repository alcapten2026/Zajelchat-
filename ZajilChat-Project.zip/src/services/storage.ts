import { Message, Conversation, UserProfile, BlockedDevice } from '../types';

const DB_NAME = 'ZajilChatDB';
const DB_VERSION = 1;
const STORE_MESSAGES = 'messages';
const STORE_CONVERSATIONS = 'conversations';
const STORE_BLOCKED = 'blocked_devices';
const STORE_SETTINGS = 'settings';

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error('IndexedDB not supported'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains(STORE_MESSAGES)) {
        const messageStore = db.createObjectStore(STORE_MESSAGES, { keyPath: 'id' });
        messageStore.createIndex('conversationId', 'conversationId', { unique: false });
        messageStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      if (!db.objectStoreNames.contains(STORE_CONVERSATIONS)) {
        db.createObjectStore(STORE_CONVERSATIONS, { keyPath: 'id' });
      }

      if (!db.objectStoreNames.contains(STORE_BLOCKED)) {
        db.createObjectStore(STORE_BLOCKED, { keyPath: 'id' });
      }

      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// ----------------- Profile -----------------
const PROFILE_KEY = 'zajil_user_profile';

export function getStoredProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading profile from localStorage', e);
  }

  // Generate random default Bluetooth MAC address
  const randomHex = () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0').toUpperCase();
  const simulatedMac = `74:D2:${randomHex()}:${randomHex()}:${randomHex()}:${randomHex()}`;

  const defaultProfile: UserProfile = {
    id: `zajil_usr_${Date.now()}`,
    name: 'مستخدم زاجل',
    bio: 'أستخدم زاجل شات للتواصل المشفر عبر البلوتوث أوفلاين 🕊️',
    avatar: '🕊️',
    bluetoothAddress: simulatedMac,
    bluetoothName: 'Zajil_Galaxy_Device',
    createdAt: Date.now(),
  };

  saveStoredProfile(defaultProfile);
  return defaultProfile;
}

export function saveStoredProfile(profile: UserProfile): void {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  } catch (e) {
    console.error('Failed to save profile', e);
  }
}

// ----------------- Blocked Devices -----------------
export async function getBlockedDevices(): Promise<BlockedDevice[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_BLOCKED, 'readonly');
      const store = tx.objectStore(STORE_BLOCKED);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  } catch (e) {
    const raw = localStorage.getItem('zajil_blocked_devices');
    return raw ? JSON.parse(raw) : [];
  }
}

export async function blockDevice(device: BlockedDevice): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction(STORE_BLOCKED, 'readwrite');
    tx.objectStore(STORE_BLOCKED).put(device);
  } catch (e) {
    const list = await getBlockedDevices();
    list.push(device);
    localStorage.setItem('zajil_blocked_devices', JSON.stringify(list));
  }
}

export async function unblockDevice(deviceId: string): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction(STORE_BLOCKED, 'readwrite');
    tx.objectStore(STORE_BLOCKED).delete(deviceId);
  } catch (e) {
    const list = await getBlockedDevices();
    const filtered = list.filter((d) => d.id !== deviceId);
    localStorage.setItem('zajil_blocked_devices', JSON.stringify(filtered));
  }
}

// ----------------- Conversations -----------------
export async function getStoredConversations(): Promise<Conversation[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_CONVERSATIONS, 'readonly');
      const store = tx.objectStore(STORE_CONVERSATIONS);
      const req = store.getAll();
      req.onsuccess = () => {
        if (req.result && req.result.length > 0) {
          resolve(req.result);
        } else {
          // Provide default initial rooms
          const defaultRooms: Conversation[] = [
            {
              id: 'room_general',
              type: 'group',
              name: 'الغرفة العامة (Mesh)',
              avatar: '🌐',
              isPasswordProtected: false,
              lastMessage: 'مرحباً بكم في شبكة زاجل شات المحلية عبر البلوتوث!',
              lastMessageTime: Date.now() - 3600000,
              unreadCount: 0,
              membersCount: 8,
              description: 'غرفة بث عامة لجميع أجهزة البلوتوث المحيطة في نطاق 10-50 متر.',
            },
            {
              id: 'room_encrypted_vip',
              type: 'group',
              name: 'القناة المشفرة VIP',
              avatar: '🔐',
              isPasswordProtected: true,
              channelPassword: '123',
              isUnlocked: true,
              lastMessage: 'قناة محمية بكلمة مرور وتشفير AES-256-GCM عسكري.',
              lastMessageTime: Date.now() - 1800000,
              unreadCount: 0,
              membersCount: 4,
              description: 'غرفة مغلقة برمز سري مشفرة بـ PBKDF2 و AES-GCM.',
            },
            {
              id: 'conv_device_falcon',
              type: 'direct',
              name: 'هاتف الصقر (Galaxy S24)',
              avatar: '📱',
              peerDeviceId: '74:D2:1D:9C:AA:45',
              isPasswordProtected: false,
              lastMessage: 'تم الاتصال عبر البلوتوث المباشر RFCOMM بنجاح.',
              lastMessageTime: Date.now() - 600000,
              unreadCount: 0,
              description: 'محادثة خاصة ومباشرة P2P عبر البلوتوث.',
            },
          ];
          saveStoredConversations(defaultRooms);
          resolve(defaultRooms);
        }
      };
      req.onerror = () => resolve([]);
    });
  } catch (e) {
    const raw = localStorage.getItem('zajil_conversations');
    return raw ? JSON.parse(raw) : [];
  }
}

export async function saveConversation(conversation: Conversation): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction(STORE_CONVERSATIONS, 'readwrite');
    tx.objectStore(STORE_CONVERSATIONS).put(conversation);
  } catch (e) {
    const convs = await getStoredConversations();
    const idx = convs.findIndex((c) => c.id === conversation.id);
    if (idx >= 0) convs[idx] = conversation;
    else convs.push(conversation);
    localStorage.setItem('zajil_conversations', JSON.stringify(convs));
  }
}

export async function saveStoredConversations(conversations: Conversation[]): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction(STORE_CONVERSATIONS, 'readwrite');
    const store = tx.objectStore(STORE_CONVERSATIONS);
    for (const c of conversations) {
      store.put(c);
    }
  } catch (e) {
    localStorage.setItem('zajil_conversations', JSON.stringify(conversations));
  }
}

// ----------------- Messages -----------------
export async function getStoredMessages(conversationId: string): Promise<Message[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_MESSAGES, 'readonly');
      const store = tx.objectStore(STORE_MESSAGES);
      const index = store.index('conversationId');
      const req = index.getAll(conversationId);
      req.onsuccess = () => {
        const msgs = (req.result || []) as Message[];
        msgs.sort((a, b) => a.timestamp - b.timestamp);
        resolve(msgs);
      };
      req.onerror = () => resolve([]);
    });
  } catch (e) {
    const raw = localStorage.getItem(`zajil_msgs_${conversationId}`);
    return raw ? JSON.parse(raw) : [];
  }
}

export async function saveStoredMessage(message: Message): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction(STORE_MESSAGES, 'readwrite');
    tx.objectStore(STORE_MESSAGES).put(message);
  } catch (e) {
    const msgs = await getStoredMessages(message.conversationId);
    msgs.push(message);
    localStorage.setItem(`zajil_msgs_${message.conversationId}`, JSON.stringify(msgs));
  }
}

export async function deleteConversationMessages(conversationId: string): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction(STORE_MESSAGES, 'readwrite');
    const store = tx.objectStore(STORE_MESSAGES);
    const index = store.index('conversationId');
    const req = index.openCursor(IDBKeyRange.only(conversationId));
    req.onsuccess = (event) => {
      const cursor = (event.target as IDBRequest<IDBCursorWithValue>).result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };
  } catch (e) {
    localStorage.removeItem(`zajil_msgs_${conversationId}`);
  }
}
