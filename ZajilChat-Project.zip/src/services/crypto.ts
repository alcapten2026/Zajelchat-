import { CryptoMetadata } from '../types';

// Convert ArrayBuffer to Base64
export function bufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

// Convert Base64 to ArrayBuffer
export function base64ToBuffer(base64: string): ArrayBuffer {
  const binary = window.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

// Convert string to Uint8Array
export function stringToBytes(str: string): Uint8Array {
  return new TextEncoder().encode(str);
}

// Convert Uint8Array to string
export function bytesToString(bytes: Uint8Array): string {
  return new TextDecoder().decode(bytes);
}

/**
 * Derive AES-256-GCM key from password or shared secret using PBKDF2
 */
export async function deriveKeyFromPassword(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const passwordKey = await window.crypto.subtle.importKey(
    'raw',
    stringToBytes(password) as unknown as BufferSource,
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as any,
      iterations: 100000,
      hash: 'SHA-256',
    },
    passwordKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Encrypt plaintext string using AES-256-GCM
 */
export async function encryptText(
  plaintext: string,
  secretOrPassword: string,
  isPasswordProtected: boolean = false
): Promise<{ ciphertextBase64: string; metadata: CryptoMetadata }> {
  // Generate 16-byte random salt
  const salt = window.crypto.getRandomValues(new Uint8Array(16));
  // Generate 12-byte (96-bit) standard IV for GCM
  const iv = window.crypto.getRandomValues(new Uint8Array(12));

  // Derive 256-bit AES key
  const key = await deriveKeyFromPassword(secretOrPassword, salt);

  const encodedData = stringToBytes(plaintext);
  const encryptedBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: iv as any,
      tagLength: 128,
    },
    key,
    encodedData as any
  );

  return {
    ciphertextBase64: bufferToBase64(encryptedBuffer),
    metadata: {
      algorithm: 'AES-256-GCM',
      iv: bufferToBase64(iv.buffer),
      salt: bufferToBase64(salt.buffer),
      tagLength: 128,
      isPasswordProtected,
    },
  };
}

/**
 * Decrypt ciphertext using AES-256-GCM
 */
export async function decryptText(
  ciphertextBase64: string,
  secretOrPassword: string,
  metadata: CryptoMetadata
): Promise<string> {
  const ciphertextBuffer = base64ToBuffer(ciphertextBase64);
  const iv = new Uint8Array(base64ToBuffer(metadata.iv));
  const salt = metadata.salt ? new Uint8Array(base64ToBuffer(metadata.salt)) : new Uint8Array(16);

  const key = await deriveKeyFromPassword(secretOrPassword, salt);

  try {
    const decryptedBuffer = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: iv as any,
        tagLength: 128,
      },
      key,
      ciphertextBuffer
    );

    return bytesToString(new Uint8Array(decryptedBuffer));
  } catch (error) {
    throw new Error('فشل فك التشفير: كلمة المرور غير صحيحة أو تم التلاعب بالرسالة.');
  }
}

/**
 * Encrypt file buffer/dataUrl using AES-256-GCM
 */
export async function encryptBinary(
  dataUrl: string,
  secretOrPassword: string,
  isPasswordProtected: boolean = false
): Promise<{ ciphertextBase64: string; metadata: CryptoMetadata }> {
  return encryptText(dataUrl, secretOrPassword, isPasswordProtected);
}

/**
 * Decrypt file buffer/dataUrl using AES-256-GCM
 */
export async function decryptBinary(
  ciphertextBase64: string,
  secretOrPassword: string,
  metadata: CryptoMetadata
): Promise<string> {
  return decryptText(ciphertextBase64, secretOrPassword, metadata);
}
