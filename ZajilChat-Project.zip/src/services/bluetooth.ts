import { BluetoothDevice, Message } from '../types';
import { getBlockedDevices } from './storage';

export const ZAJIL_BLUETOOTH_SERVICE_UUID = '0000feed-0000-1000-8000-00805f9b34fb';
export const ZAJIL_CHARACTERISTIC_RX_TX = '0000beef-0000-1000-8000-00805f9b34fb';

type BluetoothListener = (message: Message) => void;
type DeviceListener = (devices: BluetoothDevice[]) => void;

class BluetoothMeshManager {
  private broadcastChannel: BroadcastChannel | null = null;
  private messageListeners: Set<BluetoothListener> = new Set();
  private deviceListeners: Set<DeviceListener> = new Set();
  private discoveredDevices: Map<string, BluetoothDevice> = new Map();
  private isScanning: boolean = false;
  private currentDeviceId: string = '';
  private currentDeviceName: string = '';

  constructor() {
    this.initBroadcastChannel();
    this.initSimulatedDevices();
  }

  public setLocalDevice(id: string, name: string) {
    this.currentDeviceId = id;
    this.currentDeviceName = name;
    this.broadcastPresence();
  }

  private initBroadcastChannel() {
    if ('BroadcastChannel' in window) {
      this.broadcastChannel = new BroadcastChannel('zajil_mesh_bluetooth_bus');
      this.broadcastChannel.onmessage = async (event) => {
        const data = event.data;
        if (!data) return;

        // Check if device is blocked
        const blockedList = await getBlockedDevices();
        const isSenderBlocked = blockedList.some(
          (b) => b.id === data.senderDeviceId || b.id === data.senderId
        );
        if (isSenderBlocked) {
          console.warn(`[Zajil Bluetooth] تم حجب رسالة من جهاز محظور: ${data.senderDeviceId}`);
          return;
        }

        if (data.type === 'HEARTBEAT_PRESENCE') {
          if (data.deviceId !== this.currentDeviceId) {
            this.updateDiscoveredDevice({
              id: data.deviceId,
              name: data.deviceName,
              rssi: data.rssi || -48,
              distanceMeters: data.distanceMeters || 1.8,
              status: 'discovered',
              lastSeen: Date.now(),
              supportedServices: [ZAJIL_BLUETOOTH_SERVICE_UUID],
            });
          }
        } else if (data.type === 'MESSAGE_PAYLOAD') {
          if (data.senderDeviceId !== this.currentDeviceId) {
            this.notifyMessageListeners(data.message);
          }
        }
      };
    }
  }

  private initSimulatedDevices() {
    const mockDevices: BluetoothDevice[] = [
      {
        id: '74:D2:1D:9C:AA:45',
        name: 'هاتف الصقر (Galaxy S24)',
        rssi: -42,
        distanceMeters: 1.2,
        status: 'connected',
        lastSeen: Date.now(),
        supportedServices: [ZAJIL_BLUETOOTH_SERVICE_UUID],
      },
      {
        id: '58:E6:BA:3F:11:8B',
        name: 'جهاز البيدق (Pixel 8 Pro)',
        rssi: -65,
        distanceMeters: 4.5,
        status: 'discovered',
        lastSeen: Date.now(),
        supportedServices: [ZAJIL_BLUETOOTH_SERVICE_UUID],
      },
      {
        id: 'BC:A9:20:84:77:2E',
        name: 'هاتف الريان (Xiaomi 14)',
        rssi: -78,
        distanceMeters: 8.9,
        status: 'discovered',
        lastSeen: Date.now(),
        supportedServices: [ZAJIL_BLUETOOTH_SERVICE_UUID],
      },
    ];

    mockDevices.forEach((dev) => this.discoveredDevices.set(dev.id, dev));
  }

  public getDiscoveredDevices(): BluetoothDevice[] {
    return Array.from(this.discoveredDevices.values());
  }

  public updateDiscoveredDevice(device: BluetoothDevice) {
    this.discoveredDevices.set(device.id, device);
    this.notifyDeviceListeners();
  }

  public async startScan(): Promise<void> {
    this.isScanning = true;
    this.broadcastPresence();

    // Check Web Bluetooth API support
    const hasWebBluetooth = 'bluetooth' in navigator;
    console.log(`[Zajil Bluetooth] Scanning started. Web Bluetooth available: ${hasWebBluetooth}`);

    // Emulate discovery variance and signal changes
    const interval = setInterval(() => {
      if (!this.isScanning) {
        clearInterval(interval);
        return;
      }

      this.discoveredDevices.forEach((dev) => {
        // Jitter RSSI naturally like real RF signals (-35 to -90 dBm)
        const jitter = Math.floor(Math.random() * 7) - 3;
        const newRssi = Math.min(-30, Math.max(-95, dev.rssi + jitter));
        dev.rssi = newRssi;
        dev.distanceMeters = parseFloat(Math.pow(10, (-69 - newRssi) / (10 * 2)).toFixed(1));
        dev.lastSeen = Date.now();
      });

      this.notifyDeviceListeners();
    }, 2500);

    setTimeout(() => {
      this.isScanning = false;
      this.notifyDeviceListeners();
    }, 15000);
  }

  public stopScan() {
    this.isScanning = false;
    this.notifyDeviceListeners();
  }

  public isScanActive(): boolean {
    return this.isScanning;
  }

  /**
   * Request native hardware Bluetooth device connection via Web Bluetooth API if available
   */
  public async requestHardwareBluetoothPairing(): Promise<BluetoothDevice | null> {
    if ('bluetooth' in navigator) {
      try {
        const device = await (navigator as any).bluetooth.requestDevice({
          acceptAllDevices: true,
          optionalServices: [ZAJIL_BLUETOOTH_SERVICE_UUID, 'generic_access'],
        });

        const newDevice: BluetoothDevice = {
          id: device.id || `BT_${Date.now()}`,
          name: device.name || 'جهاز بلوتوث حقيقي غير مسمى',
          rssi: -50,
          distanceMeters: 2.0,
          status: 'connected',
          lastSeen: Date.now(),
          supportedServices: [ZAJIL_BLUETOOTH_SERVICE_UUID],
        };

        this.updateDiscoveredDevice(newDevice);
        return newDevice;
      } catch (err) {
        console.warn('[Zajil Bluetooth] User cancelled or hardware bluetooth pairing not granted', err);
        return null;
      }
    }
    return null;
  }

  public connectToDevice(deviceId: string): Promise<boolean> {
    return new Promise((resolve) => {
      const dev = this.discoveredDevices.get(deviceId);
      if (dev) {
        dev.status = 'connecting';
        this.notifyDeviceListeners();
        setTimeout(() => {
          dev.status = 'connected';
          this.notifyDeviceListeners();
          resolve(true);
        }, 800);
      } else {
        resolve(false);
      }
    });
  }

  public disconnectDevice(deviceId: string) {
    const dev = this.discoveredDevices.get(deviceId);
    if (dev) {
      dev.status = 'discovered';
      this.notifyDeviceListeners();
    }
  }

  public broadcastPresence() {
    if (this.broadcastChannel) {
      this.broadcastChannel.postMessage({
        type: 'HEARTBEAT_PRESENCE',
        deviceId: this.currentDeviceId,
        deviceName: this.currentDeviceName,
        rssi: -45,
        distanceMeters: 1.5,
      });
    }
  }

  public sendMessageOverBluetooth(message: Message): void {
    if (this.broadcastChannel) {
      this.broadcastChannel.postMessage({
        type: 'MESSAGE_PAYLOAD',
        senderDeviceId: this.currentDeviceId,
        message,
      });
    }
  }

  public onMessage(listener: BluetoothListener): () => void {
    this.messageListeners.add(listener);
    return () => this.messageListeners.delete(listener);
  }

  public onDevicesUpdated(listener: DeviceListener): () => void {
    this.deviceListeners.add(listener);
    return () => this.deviceListeners.delete(listener);
  }

  private notifyMessageListeners(message: Message) {
    this.messageListeners.forEach((fn) => fn(message));
  }

  private notifyDeviceListeners() {
    const devs = this.getDiscoveredDevices();
    this.deviceListeners.forEach((fn) => fn(devs));
  }
}

export const bluetoothManager = new BluetoothMeshManager();
