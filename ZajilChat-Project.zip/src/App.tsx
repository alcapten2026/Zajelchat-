import React, { useState, useEffect } from 'react';
import {
  UserProfile,
  Conversation,
  Message,
  BluetoothDevice,
  BlockedDevice,
  MessageType,
  CryptoMetadata
} from './types';
import {
  getStoredProfile,
  saveStoredProfile,
  getStoredConversations,
  saveConversation,
  getStoredMessages,
  saveStoredMessage,
  deleteConversationMessages,
  getBlockedDevices,
  blockDevice,
  unblockDevice
} from './services/storage';
import { encryptText, decryptText, encryptBinary, decryptBinary } from './services/crypto';
import { bluetoothManager } from './services/bluetooth';

import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { MessageInput } from './components/MessageInput';
import { RadarScanner } from './components/RadarScanner';
import { ProfileModal } from './components/ProfileModal';
import { NewChannelModal } from './components/NewChannelModal';
import { BlockedDevicesModal } from './components/BlockedDevicesModal';
import { CryptoInspectorModal } from './components/CryptoInspectorModal';
import { AndroidExporterModal } from './components/AndroidExporterModal';
import { ApkDownloadModal } from './components/ApkDownloadModal';
import { AboutModal } from './components/AboutModal';
import { UnlockChannelModal } from './components/UnlockChannelModal';
import { ArrowRight, Bluetooth } from 'lucide-react';

export default function App() {
  // Theme state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('zajil_dark_mode') === 'true';
  });

  // Profile & Data states
  const [profile, setProfile] = useState<UserProfile>(getStoredProfile);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [discoveredDevices, setDiscoveredDevices] = useState<BluetoothDevice[]>([]);
  const [blockedDevices, setBlockedDevices] = useState<BlockedDevice[]>([]);
  const [isScanning, setIsScanning] = useState<boolean>(false);

  // Modals state
  const [isRadarOpen, setIsRadarOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [newModalType, setNewModalType] = useState<'direct' | 'group'>('direct');
  const [isBlockedOpen, setIsBlockedOpen] = useState(false);
  const [isExporterOpen, setIsExporterOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isUnlockOpen, setIsUnlockOpen] = useState(false);
  const [inspectingMessage, setInspectingMessage] = useState<Message | null>(null);

  // Dark mode effect
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('zajil_dark_mode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('zajil_dark_mode', 'false');
    }
  }, [darkMode]);

  // Initial load
  useEffect(() => {
    bluetoothManager.setLocalDevice(profile.bluetoothAddress, profile.bluetoothName);

    // Load conversations & blocked devices
    getStoredConversations().then((convs) => {
      setConversations(convs);
      if (convs.length > 0 && !activeConversationId) {
        setActiveConversationId(convs[0].id);
      }
    });

    getBlockedDevices().then(setBlockedDevices);
    setDiscoveredDevices(bluetoothManager.getDiscoveredDevices());

    // Bluetooth listeners
    const unsubscribeDevices = bluetoothManager.onDevicesUpdated((devs) => {
      setDiscoveredDevices(devs);
      setIsScanning(bluetoothManager.isScanActive());
    });

    const unsubscribeMessages = bluetoothManager.onMessage(async (incomingMsg) => {
      // Check if sender is blocked
      const blocked = await getBlockedDevices();
      if (blocked.some((b) => b.id === incomingMsg.senderId)) {
        return;
      }

      // Save incoming message
      await saveStoredMessage(incomingMsg);

      // If active conversation matches, append
      setActiveConversationId((currentActive) => {
        if (currentActive === incomingMsg.conversationId) {
          setMessages((prev) => {
            if (prev.some((m) => m.id === incomingMsg.id)) return prev;
            return [...prev, incomingMsg];
          });
        }
        return currentActive;
      });

      // Update conversation snippet
      setConversations((prev) =>
        prev.map((c) => {
          if (c.id === incomingMsg.conversationId) {
            return {
              ...c,
              lastMessage: incomingMsg.type === 'text' ? incomingMsg.content : `[${incomingMsg.type}]`,
              lastMessageTime: incomingMsg.timestamp,
              unreadCount: incomingMsg.conversationId === activeConversationId ? 0 : c.unreadCount + 1,
            };
          }
          return c;
        })
      );
    });

    return () => {
      unsubscribeDevices();
      unsubscribeMessages();
    };
  }, []);

  // Load messages when active conversation changes
  useEffect(() => {
    if (activeConversationId) {
      getStoredMessages(activeConversationId).then(async (storedMsgs) => {
        // If initial demo messages need to be seeded for the first conversation
        if (storedMsgs.length === 0 && activeConversationId === 'room_general') {
          const welcomeMsg: Message = {
            id: 'msg_welcome_1',
            conversationId: 'room_general',
            senderId: 'sys_beacon',
            senderName: 'منارة زاجل (Beacon)',
            senderAvatar: '📡',
            content: 'أهلاً بك في شبكة زاجل شات الميدانية. جميع الرسائل هنا مشفرة محلياً بـ AES-256-GCM وتتنقل عبر البلوتوث مباشرة دون إنترنت.',
            type: 'text',
            cryptoMeta: {
              algorithm: 'AES-256-GCM',
              iv: 'tZ5Qo9vX2kL8+pY=',
              tagLength: 128,
              isPasswordProtected: false,
            },
            timestamp: Date.now() - 3600000,
            status: 'delivered',
            isDecrypted: true,
          };
          await saveStoredMessage(welcomeMsg);
          setMessages([welcomeMsg]);
        } else {
          setMessages(storedMsgs);
        }
      });
    } else {
      setMessages([]);
    }
  }, [activeConversationId]);

  const activeConversation = conversations.find((c) => c.id === activeConversationId) || null;

  // Determine if active channel is currently locked
  const isChannelLocked = Boolean(
    activeConversation &&
    activeConversation.isPasswordProtected &&
    !activeConversation.isUnlocked
  );

  // Send a new message
  const handleSendMessage = async (
    content: string,
    type: MessageType,
    fileData?: { name: string; size: number; mimeType: string; dataUrl: string; duration?: number }
  ) => {
    if (!activeConversation) return;

    const secretKeyOrPass = activeConversation.channelPassword || 'ZAJIL_DEFAULT_MESH_SECRET_KEY';

    let ciphertextBase64 = '';
    let metadata: CryptoMetadata;

    if (type === 'text') {
      const encrypted = await encryptText(
        content,
        secretKeyOrPass,
        activeConversation.isPasswordProtected
      );
      ciphertextBase64 = encrypted.ciphertextBase64;
      metadata = encrypted.metadata;
    } else if (fileData) {
      const encrypted = await encryptBinary(
        fileData.dataUrl,
        secretKeyOrPass,
        activeConversation.isPasswordProtected
      );
      ciphertextBase64 = encrypted.ciphertextBase64;
      metadata = encrypted.metadata;
    } else {
      return;
    }

    const newMessage: Message = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      conversationId: activeConversation.id,
      senderId: profile.id,
      senderName: profile.name,
      senderAvatar: profile.avatar,
      content,
      encryptedPayload: ciphertextBase64,
      cryptoMeta: metadata,
      type,
      fileData,
      timestamp: Date.now(),
      status: 'delivered',
      isDecrypted: true,
    };

    // Save locally to IndexedDB
    await saveStoredMessage(newMessage);
    setMessages((prev) => [...prev, newMessage]);

    // Send over Bluetooth Mesh/RFCOMM
    bluetoothManager.sendMessageOverBluetooth(newMessage);

    // Update conversation
    const updatedConv: Conversation = {
      ...activeConversation,
      lastMessage: type === 'text' ? content : `[${type}]`,
      lastMessageTime: newMessage.timestamp,
      unreadCount: 0,
    };
    await saveConversation(updatedConv);
    setConversations((prev) => prev.map((c) => (c.id === updatedConv.id ? updatedConv : c)));
  };

  // Block a device
  const handleBlockDevice = async (deviceId: string, deviceName: string) => {
    if (window.confirm(`هل أنت متأكد من رغبتك في حظر الجهاز "${deviceName}" (${deviceId})؟`)) {
      const newBlocked: BlockedDevice = {
        id: deviceId,
        name: deviceName,
        blockedAt: Date.now(),
      };
      await blockDevice(newBlocked);
      const list = await getBlockedDevices();
      setBlockedDevices(list);
      bluetoothManager.disconnectDevice(deviceId);
      alert(`تم حظر الجهاز ${deviceName} بنجاح. لن تستلم أي رسائل منه.`);
    }
  };

  // Unblock a device
  const handleUnblockDevice = async (deviceId: string) => {
    await unblockDevice(deviceId);
    const list = await getBlockedDevices();
    setBlockedDevices(list);
  };

  // Clear chat history
  const handleClearHistory = async () => {
    if (!activeConversation) return;
    if (window.confirm('هل تريد بالتأكيد حذف جميع رسائل هذه المحادثة من الذاكرة المحلية؟')) {
      await deleteConversationMessages(activeConversation.id);
      setMessages([]);
      const updatedConv = { ...activeConversation, lastMessage: '', lastMessageTime: undefined };
      await saveConversation(updatedConv);
      setConversations((prev) => prev.map((c) => (c.id === updatedConv.id ? updatedConv : c)));
    }
  };

  // Create new conversation/room
  const handleCreateConversation = async (data: Partial<Conversation>) => {
    const newConv: Conversation = {
      id: data.id || `conv_${Date.now()}`,
      type: data.type || 'direct',
      name: data.name || 'محادثة جديدة',
      avatar: data.avatar || '💬',
      peerDeviceId: data.peerDeviceId,
      isPasswordProtected: Boolean(data.isPasswordProtected),
      channelPassword: data.channelPassword,
      isUnlocked: true,
      unreadCount: 0,
      membersCount: data.membersCount || 1,
      description: data.description,
      lastMessageTime: Date.now(),
    };

    await saveConversation(newConv);
    setConversations((prev) => [newConv, ...prev]);
    setActiveConversationId(newConv.id);
  };

  // Connect to discovered device from Radar
  const handleConnectFromRadar = async (dev: BluetoothDevice) => {
    await bluetoothManager.connectToDevice(dev.id);

    // Look for existing conversation with this device
    const existing = conversations.find((c) => c.peerDeviceId === dev.id);
    if (existing) {
      setActiveConversationId(existing.id);
      setIsRadarOpen(false);
    } else {
      // Create new direct conversation
      handleCreateConversation({
        id: `conv_peer_${dev.id.replace(/[^a-zA-Z0-9]/g, '')}`,
        type: 'direct',
        name: dev.name,
        avatar: '📱',
        peerDeviceId: dev.id,
        isPasswordProtected: false,
        description: `محادثة بلوتوث مباشرة P2P مع ${dev.id}`,
      });
      setIsRadarOpen(false);
    }
  };

  // Unlock channel password
  const handleUnlockChannelSuccess = (pwd: string) => {
    if (!activeConversation) return;
    const updated = {
      ...activeConversation,
      channelPassword: pwd,
      isUnlocked: true,
    };
    saveConversation(updated);
    setConversations((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-sky-50 dark:bg-slate-950 font-['Cairo'] text-slate-900 dark:text-slate-100 selection:bg-sky-500 selection:text-white antialiased">
      {/* Top Navbar */}
      <Navbar
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onOpenRadar={() => setIsRadarOpen(true)}
        onOpenExporter={() => setIsExporterOpen(true)}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenBlocked={() => setIsBlockedOpen(true)}
        onOpenAbout={() => setIsAboutOpen(true)}
        activeDeviceCount={discoveredDevices.filter((d) => d.status === 'connected').length}
        profile={profile}
      />

      {/* Main App Content Layout */}
      <main className="flex-1 flex overflow-hidden max-w-7xl w-full mx-auto shadow-xl border-x border-sky-100 dark:border-slate-800">
        {/* Sidebar (Conversations) */}
        <div
          className={`h-full ${
            activeConversationId ? 'hidden md:flex' : 'flex'
          } w-full md:w-80 lg:w-96 flex-col`}
        >
          <Sidebar
            conversations={conversations}
            activeId={activeConversationId}
            onSelectConversation={(id) => setActiveConversationId(id)}
            onOpenNewModal={(t) => {
              setNewModalType(t);
              setIsNewModalOpen(true);
            }}
            onOpenBlocked={() => setIsBlockedOpen(true)}
            onOpenAbout={() => setIsAboutOpen(true)}
          />
        </div>

        {/* Chat Area & Input */}
        <div
          className={`flex-1 flex flex-col h-full bg-white dark:bg-slate-900 ${
            !activeConversationId ? 'hidden md:flex' : 'flex'
          }`}
        >
          {/* Mobile Back Button */}
          {activeConversation && (
            <div className="md:hidden px-3 py-2 bg-sky-100 dark:bg-slate-800 border-b border-sky-200 dark:border-slate-700 flex items-center gap-2">
              <button
                onClick={() => setActiveConversationId(null)}
                className="flex items-center gap-1.5 text-xs font-bold text-sky-700 dark:text-sky-300 px-2 py-1 rounded-lg hover:bg-sky-200 dark:hover:bg-slate-700 transition"
              >
                <ArrowRight className="w-4 h-4" />
                <span>العودة للمحادثات</span>
              </button>
            </div>
          )}

          <ChatArea
            conversation={activeConversation}
            messages={messages}
            currentProfile={profile}
            onBlockPeer={(peerId, peerName) => handleBlockDevice(peerId, peerName)}
            onClearHistory={handleClearHistory}
            onInspectCrypto={(msg) => setInspectingMessage(msg)}
            onPromptUnlock={() => setIsUnlockOpen(true)}
            isLocked={isChannelLocked}
          />

          {activeConversation && (
            <MessageInput
              onSendMessage={handleSendMessage}
              isLocked={isChannelLocked}
              onPromptUnlock={() => setIsUnlockOpen(true)}
            />
          )}
        </div>
      </main>

      {/* Modals */}
      <RadarScanner
        isOpen={isRadarOpen}
        onClose={() => setIsRadarOpen(false)}
        devices={discoveredDevices}
        onConnect={handleConnectFromRadar}
        onBlock={(d) => handleBlockDevice(d.id, d.name)}
        isScanning={isScanning}
        onRefreshScan={() => bluetoothManager.startScan()}
      />

      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        profile={profile}
        onSave={(updated) => {
          setProfile(updated);
          saveStoredProfile(updated);
          bluetoothManager.setLocalDevice(updated.bluetoothAddress, updated.bluetoothName);
        }}
      />

      <NewChannelModal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
        initialType={newModalType}
        discoveredDevices={discoveredDevices}
        onCreate={handleCreateConversation}
      />

      <BlockedDevicesModal
        isOpen={isBlockedOpen}
        onClose={() => setIsBlockedOpen(false)}
        blockedDevices={blockedDevices}
        onUnblock={handleUnblockDevice}
      />

      <CryptoInspectorModal
        isOpen={Boolean(inspectingMessage)}
        onClose={() => setInspectingMessage(null)}
        message={inspectingMessage}
      />

      <AndroidExporterModal
        isOpen={isExporterOpen}
        onClose={() => setIsExporterOpen(false)}
      />

      <ApkDownloadModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
        onOpenSourceModal={() => setIsExporterOpen(true)}
      />

      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
      />

      {activeConversation && (
        <UnlockChannelModal
          isOpen={isUnlockOpen}
          onClose={() => setIsUnlockOpen(false)}
          channelName={activeConversation.name}
          expectedPassword={activeConversation.channelPassword}
          onSuccess={handleUnlockChannelSuccess}
        />
      )}
    </div>
  );
}
